#Calvin Tracy
#CS 120 02
#Program Assignment Chapter 02
#Due Date Sept 18th
#Date turned in
#Calculate the purchase if an item to include state and county sales tax.

print('Enter amount of purchase')
purchase_amount = int(input())

state_tax = 0.50
county_tax = 0.25
total_sales_tax = purchase_amount * state_tax * county_tax

total_purchase = purchase_amount + total_sales_tax

print('State Tax =', state_tax)
print('County Tax =',county_tax)
print('Total sales tax=', total_sales_tax)
print('Total Purchse',total_purchase)
