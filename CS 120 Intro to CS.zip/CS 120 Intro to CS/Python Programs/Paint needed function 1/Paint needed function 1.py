# Calvin Tracy
# CS 120 02
# Program Assignment 05
# Wednesday, November 8, 2017
#


hours_labor_cost = 35

def gallons_paint_req(num_gal):
    min_wall_length = 112
    gallons_needed = num_gal / min_wall_length
    return gallons_needed # gallons req

def hours_labor_req(hrs_labor):
    total_hours_cost = hrs_labor * gallons_needed
    return total_hours_cost # hours of labor req

def paint_cost():
    gallons_paint_cost = gallons_needed * 15
    return gallons_paint_cost # total cost of paint

def labor_charges():
    labor_charge = total_hours_cost * hours_labor_cost
    return labor_charge #total labor charges

def paint_job_cost():
    full_cost = gallons_paint_cost + labor_charge
    return full_cost
    


space_to_be_painted = int(input('Enter square feet of wall space to be painted:'))

gallons_needed = gallons_paint_req(space_to_be_painted) #gallons_needed will be whatever the expression equals in the function 'gallons_paint_req.'
print('Gallons needed: %.3f' % (gallons_needed))

hrs_labor = 8
total_hours_cost = hours_labor_req(hrs_labor) #total_hours_cost will be whatever the expression equals in the function 'hours_labor_req.'
print('Hours of labor required: %.2f' % (total_hours_cost))

gallons_paint_cost = paint_cost() #gallons_paint_cost will be whatever the expression equals in the function 'paint_cost.'
print('Total cost of paint: $ %.2f' % (gallons_paint_cost))

labor_charge = labor_charges() #labor_charge will be whatever the expression equals in the function 'labor_charges.'
print('Total labor charges: $ %.2f' % (labor_charge))

full_cost = paint_job_cost() #full_cost will be whatever the expression equals in the function 'def paint_job_cost.'
print('Total cost of paint job: $ %.2f' % (full_cost))


#programmer notes to self#

# gallons_needed, total_hours_cost, gallons_paint_cost, labor_charge, and full_cost; are all set to equal whatever the user defined function is, above the print statements.
# this is because you MUST define the variable above the print statements so that it may carry over to the function statements.
# for example, if you do not set 'full_cost = paint_job_cost()' above the print statement, when the program executes you will get the following error, 'NameError: name 'full_cost' is not defined'

# gallons_needed, total_hours_cost, gallons_paint_cost, labor_charge, and full_cost; are all set to equal whatever the user defined function is, above the print statements.
# and so are put into the print statements which will print out the sum of the expression that the 'return' funcetion executes. 
