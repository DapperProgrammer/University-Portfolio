keepgoing = 'Y'

while keepgoing  == 'Y':
    sales = float(input('Enter amount of sales'))
    commissionrate = float(input('Enter commission rate'))
    commission = sales * commissionrate
    print('The commission is $', format(commission, ',.2f'), sep = '')
    keepgoing = input('Do you want to calculate another commission?')
