final_numbers = open('final numbers.txt')
contents = final_numbers.read()


