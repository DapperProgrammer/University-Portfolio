max_temp = 102.5
sub_temp = float(input('Enter substance temp:'))

while sub_temp > max_temp:
    print('The temp is to high')
    print('turn thermosat down and wait')
    print('5 minutes. Then take the tempature')
    print('Again and enter it.')
    sub_temp = float(input('Enter substance temp'))
print('The temperature is acceptable')
print('Check again in 15 minutes')
