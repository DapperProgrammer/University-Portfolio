# Calvin Tracy
# CS 120 02
# Program Assignment 03
# October 16th
# 10/09/17
# Show number of points earned per number of books purchased. 

purchased_books = int(input('Enter number of books purchased:'))
num_points = 0

if purchased_books <= 1:
    print('You earned 0 points:')
elif purchased_books <= 3:
    print('You earned 5 points:')
elif purchased_books <= 5:
    print ('You earned 15 points:')
elif purchased_books <=7:
    print ('You earned 30 points:')
else:
    print ('You earned 60 points:')
