# Calvin Tracy
# CS 120 02
# Program Assignment 04
# Friday, October, 27, 2017
# 10/27/17
# Predict and print out the approximate 'x' population size and growth over 'y' amount of days.
 
num_organisms = int(input('Enter your starting number of organisms:\n'))
pop_increase = int(input('Enter the average population increase as a percentage, e.g. "50:"\n'))
num_days = int(input('Enter number of days your organisms will be left to multiply:\n'))

pop_percent = pop_increase / 100

i = 1
while i <= num_days:
    print('Day %d: Approximate Population: %s' % (i, num_organisms))
    num_organisms = num_organisms * pop_percent + num_organisms
    i = i + 1

