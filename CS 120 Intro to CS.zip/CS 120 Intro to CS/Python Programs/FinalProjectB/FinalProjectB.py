#Calvin Tracy
#CS 120 02
#Final Project B
#December 11, 2017
#December 4, 2017 
#Calculate the standard deviation of a population in a given file. 



import math
numbers = open('numbers.txt')
num_dict = numbers.readlines()

def mean():
  count = 0 #initialize the variable count to be used in calculations later 
  for N in num_dict: #Assigns the variable 'N' to all the numbers in the num_dict
    count = count + int(N) #int() turns numbers in the file numbers.txt into integers, adds them together. 0=0+2, 2=2+5 for len of num_dict
  total = count/len(num_dict) #divides the total of all numbers (count) in the file numbers.txt by the amount of numbers there are (len). 
  return total #returns the mean value
  
print('The mean is', mean()) # Calls the function

def total_difference():
  count = 0
  line_count = sum(1 for line in open('numbers.txt'))
  for i in num_dict:
    total = int(i) - mean() #Subtracts mean from each number in numbers.txt
    total_sq = (total**2) #Squares each number
    count = count + total_sq #Adds all numbers together with the total_sq

  total_deviation = math.sqrt(count / line_count) 
  return total_deviation
print('The standard deviation is:', total_difference()) # Calls the function
  
