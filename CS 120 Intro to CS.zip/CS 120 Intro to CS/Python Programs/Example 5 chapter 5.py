start_speed = 60
max_speed = 131
increment = 10
conversion_factor = 0.6214
print('kph/tmph')
print('-----------')
for kph in range(start_speed, max_speed, increment):
    mph = kph * conversion_factor
    print(kph, '=', format(mph,'.1f'))
