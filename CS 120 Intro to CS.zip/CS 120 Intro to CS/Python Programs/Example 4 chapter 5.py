for x in range(5):
    print('hello world')


for x in range (1, 11):
    print(x), x + x
