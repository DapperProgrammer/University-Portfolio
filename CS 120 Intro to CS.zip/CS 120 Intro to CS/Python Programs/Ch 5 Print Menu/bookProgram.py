def menu():
    print("Menu")
    print("c - Number of non-whitespace characters")
    print("w - Number of words")
    print("f - Fix capitalization")
    print("r - Replace punctuation")
    print("s - Shorten spaces")
    print("q - Quit")
    option = input("Choose an option: ")
    return option # goes to main function def main():

def numWhite(text):
    print("In numWhite")
    for l in text:
        if l != ' ' and l != '\n' and l != '\t':
            letters += 1
    return 0

def numberOfWords(text):
    count = 0
    for position in range(len(text)):
        if text(position) == ' ' and text(position -1) != ' ':
            count += 1
    count+=1
    return count 

def fixCap(text):
    countChanges = 0
    newText = ''
    position = 0
    while position < (len(text)):
        if text(position) == '.':
            position += 1
        while position 
            
    return text, 0

def replaceText(text):
    print("In replaceText")
    return text

def shortenSpaces(text):
    print("In shortenSpaces")
    return text

def main(): # begins main funct
    text = input("Enter a sample text: ")
    print("You entered: ", text)
    choice = menu()
    while choice != "q":
        if choice == "c":
            numWhitespace = numWhite(text)
            print("Number of non-whitespace characters:", numWhitespace)
        elif choice == "w":
            numWords = numberOfWords(text)
            print("Number of words", numWords)
        elif choice == "f":
            capText, count = fixCap(text)
            print("Number of words capitalized", count)
            print("Edited text:", capText)
        elif choice == "r":
            replText = replaceText(text)
            print("Edited text:", replText)
        elif choice == "s":
            shText = shortenSpaces(text)
            print("Edited text:", shText)
        choice = menu()
main() #close main func

