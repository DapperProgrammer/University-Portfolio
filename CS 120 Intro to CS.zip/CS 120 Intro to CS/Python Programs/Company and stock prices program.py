# Calvin Tracy
# CS 120 02
# Program Assignment 02
# Friday, September 29, 2017
# 09/27/2017
# Output the number of shares purchased, sold, value of shares, broker comission
# and your total profit if any. 






companyName = input('Enter name of company:\n')
numberOfShares = int(input('Enter number of shares to purchase:\n'))
amountPerShare = float(input('Enter amount per share:\n'))
numberShareSell = int(input('Enter number of shares to sell:\n'))
amountPerShareSell = float(input('Amount per share sold:\n'))

print ('')

print ('Company Name:', companyName)
print ('Number of shares purchased:', numberOfShares)
print ('Amount per share:', amountPerShare)
print ('Number of shares sold:', numberShareSell)
print ('Amount per share sold:', amountPerShareSell)

print ('')

total_stock_price = amountPerShare * numberOfShares

print ('Amount paid for stock $', total_stock_price)

broker_commission = total_stock_price * 0.03

print ('Broker commission $',broker_commission)

print ('')

amount_stock_sold_for = amountPerShareSell * numberOfShares

print ('Amount stock sold for $', amount_stock_sold_for)

broker_commission_2 = amount_stock_sold_for * 0.03

print ('Broker commission after stock sale $', broker_commission_2)

print ('')

print ('After selling the stock you have $', amount_stock_sold_for)

total_broker_commission = broker_commission + broker_commission_2

print ('You paid your broker a total of $', total_broker_commission)

total_profit = amount_stock_sold_for - total_broker_commission - total_stock_price

print ('Your total profit is $', total_profit)
