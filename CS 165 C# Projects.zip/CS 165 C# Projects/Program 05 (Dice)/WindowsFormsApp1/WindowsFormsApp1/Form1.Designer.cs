﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnDiceRoll = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.Label();
            this.pbDr11 = new System.Windows.Forms.PictureBox();
            this.pbDr21 = new System.Windows.Forms.PictureBox();
            this.pbDr12 = new System.Windows.Forms.PictureBox();
            this.pbDr13 = new System.Windows.Forms.PictureBox();
            this.pbDr14 = new System.Windows.Forms.PictureBox();
            this.pbDr15 = new System.Windows.Forms.PictureBox();
            this.pbDr16 = new System.Windows.Forms.PictureBox();
            this.pbDr22 = new System.Windows.Forms.PictureBox();
            this.pbDr26 = new System.Windows.Forms.PictureBox();
            this.pbDr25 = new System.Windows.Forms.PictureBox();
            this.pbDr23 = new System.Windows.Forms.PictureBox();
            this.pbDr24 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr24)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDiceRoll
            // 
            this.btnDiceRoll.Location = new System.Drawing.Point(109, 190);
            this.btnDiceRoll.Name = "btnDiceRoll";
            this.btnDiceRoll.Size = new System.Drawing.Size(84, 45);
            this.btnDiceRoll.TabIndex = 0;
            this.btnDiceRoll.Text = "Roll Dice";
            this.btnDiceRoll.UseVisualStyleBackColor = true;
            this.btnDiceRoll.Click += new System.EventHandler(this.btnDiceRoll_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(109, 264);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(84, 44);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutput.Location = new System.Drawing.Point(93, 135);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(111, 39);
            this.lblOutput.TabIndex = 2;
            // 
            // pbDr11
            // 
            this.pbDr11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr11.BackgroundImage")));
            this.pbDr11.ErrorImage = null;
            this.pbDr11.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr11.InitialImage")));
            this.pbDr11.Location = new System.Drawing.Point(15, 10);
            this.pbDr11.Name = "pbDr11";
            this.pbDr11.Size = new System.Drawing.Size(103, 104);
            this.pbDr11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDr11.TabIndex = 3;
            this.pbDr11.TabStop = false;
            // 
            // pbDr21
            // 
            this.pbDr21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr21.BackgroundImage")));
            this.pbDr21.ErrorImage = null;
            this.pbDr21.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr21.InitialImage")));
            this.pbDr21.Location = new System.Drawing.Point(200, 9);
            this.pbDr21.Name = "pbDr21";
            this.pbDr21.Size = new System.Drawing.Size(104, 104);
            this.pbDr21.TabIndex = 4;
            this.pbDr21.TabStop = false;
            // 
            // pbDr12
            // 
            this.pbDr12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr12.BackgroundImage")));
            this.pbDr12.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr12.InitialImage")));
            this.pbDr12.Location = new System.Drawing.Point(15, 10);
            this.pbDr12.Name = "pbDr12";
            this.pbDr12.Size = new System.Drawing.Size(103, 105);
            this.pbDr12.TabIndex = 5;
            this.pbDr12.TabStop = false;
            this.pbDr12.Visible = false;
            // 
            // pbDr13
            // 
            this.pbDr13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr13.BackgroundImage")));
            this.pbDr13.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr13.InitialImage")));
            this.pbDr13.Location = new System.Drawing.Point(15, 10);
            this.pbDr13.Name = "pbDr13";
            this.pbDr13.Size = new System.Drawing.Size(104, 105);
            this.pbDr13.TabIndex = 6;
            this.pbDr13.TabStop = false;
            this.pbDr13.Visible = false;
            // 
            // pbDr14
            // 
            this.pbDr14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr14.BackgroundImage")));
            this.pbDr14.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr14.InitialImage")));
            this.pbDr14.Location = new System.Drawing.Point(15, 9);
            this.pbDr14.Name = "pbDr14";
            this.pbDr14.Size = new System.Drawing.Size(104, 104);
            this.pbDr14.TabIndex = 7;
            this.pbDr14.TabStop = false;
            this.pbDr14.Visible = false;
            // 
            // pbDr15
            // 
            this.pbDr15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr15.BackgroundImage")));
            this.pbDr15.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr15.InitialImage")));
            this.pbDr15.Location = new System.Drawing.Point(16, 10);
            this.pbDr15.Name = "pbDr15";
            this.pbDr15.Size = new System.Drawing.Size(103, 104);
            this.pbDr15.TabIndex = 8;
            this.pbDr15.TabStop = false;
            this.pbDr15.Visible = false;
            // 
            // pbDr16
            // 
            this.pbDr16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr16.BackgroundImage")));
            this.pbDr16.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr16.InitialImage")));
            this.pbDr16.Location = new System.Drawing.Point(16, 9);
            this.pbDr16.Name = "pbDr16";
            this.pbDr16.Size = new System.Drawing.Size(103, 104);
            this.pbDr16.TabIndex = 9;
            this.pbDr16.TabStop = false;
            this.pbDr16.Visible = false;
            // 
            // pbDr22
            // 
            this.pbDr22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr22.BackgroundImage")));
            this.pbDr22.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr22.InitialImage")));
            this.pbDr22.Location = new System.Drawing.Point(200, 9);
            this.pbDr22.Name = "pbDr22";
            this.pbDr22.Size = new System.Drawing.Size(104, 104);
            this.pbDr22.TabIndex = 10;
            this.pbDr22.TabStop = false;
            this.pbDr22.Visible = false;
            // 
            // pbDr26
            // 
            this.pbDr26.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Die6;
            this.pbDr26.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr26.InitialImage")));
            this.pbDr26.Location = new System.Drawing.Point(200, 10);
            this.pbDr26.Name = "pbDr26";
            this.pbDr26.Size = new System.Drawing.Size(104, 104);
            this.pbDr26.TabIndex = 11;
            this.pbDr26.TabStop = false;
            this.pbDr26.Visible = false;
            // 
            // pbDr25
            // 
            this.pbDr25.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Die5;
            this.pbDr25.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr25.InitialImage")));
            this.pbDr25.Location = new System.Drawing.Point(200, 9);
            this.pbDr25.Name = "pbDr25";
            this.pbDr25.Size = new System.Drawing.Size(104, 104);
            this.pbDr25.TabIndex = 12;
            this.pbDr25.TabStop = false;
            this.pbDr25.Visible = false;
            // 
            // pbDr23
            // 
            this.pbDr23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDr23.BackgroundImage")));
            this.pbDr23.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr23.InitialImage")));
            this.pbDr23.Location = new System.Drawing.Point(200, 9);
            this.pbDr23.Name = "pbDr23";
            this.pbDr23.Size = new System.Drawing.Size(104, 104);
            this.pbDr23.TabIndex = 13;
            this.pbDr23.TabStop = false;
            this.pbDr23.Visible = false;
            // 
            // pbDr24
            // 
            this.pbDr24.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Die4;
            this.pbDr24.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDr24.InitialImage")));
            this.pbDr24.Location = new System.Drawing.Point(200, 9);
            this.pbDr24.Name = "pbDr24";
            this.pbDr24.Size = new System.Drawing.Size(104, 104);
            this.pbDr24.TabIndex = 14;
            this.pbDr24.TabStop = false;
            this.pbDr24.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 345);
            this.Controls.Add(this.pbDr24);
            this.Controls.Add(this.pbDr23);
            this.Controls.Add(this.pbDr25);
            this.Controls.Add(this.pbDr26);
            this.Controls.Add(this.pbDr22);
            this.Controls.Add(this.pbDr16);
            this.Controls.Add(this.pbDr15);
            this.Controls.Add(this.pbDr14);
            this.Controls.Add(this.pbDr13);
            this.Controls.Add(this.pbDr12);
            this.Controls.Add(this.pbDr21);
            this.Controls.Add(this.pbDr11);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDiceRoll);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbDr11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDr24)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDiceRoll;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.PictureBox pbDr11;
        private System.Windows.Forms.PictureBox pbDr21;
        private System.Windows.Forms.PictureBox pbDr12;
        private System.Windows.Forms.PictureBox pbDr13;
        private System.Windows.Forms.PictureBox pbDr14;
        private System.Windows.Forms.PictureBox pbDr15;
        private System.Windows.Forms.PictureBox pbDr16;
        private System.Windows.Forms.PictureBox pbDr22;
        private System.Windows.Forms.PictureBox pbDr26;
        private System.Windows.Forms.PictureBox pbDr25;
        private System.Windows.Forms.PictureBox pbDr23;
        private System.Windows.Forms.PictureBox pbDr24;
    }
}

