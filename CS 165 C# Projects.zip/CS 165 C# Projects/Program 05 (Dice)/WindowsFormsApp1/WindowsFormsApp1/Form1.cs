﻿//Calvin Tracy
//CS 165 01
//Program 05
//11/06/18
//Game of craps
// "pbDr12" "Means picture box Dice1 image 2" "pbDr13" means "Picture box Dice 1 image 3" ect.
// The picture boxes holding the images of the dice on point 1 are intialized to "True" so the user can see the images

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDiceRoll_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            //outputFile = File.CreateText("Craps.txt");
            Random rnd = new Random();
            int pointsTotal = 0;
            int crapsPoint = 0;
            int Dice1 = rnd.Next(1, 7);
            int Dice2 = rnd.Next(1, 7);
            //while (pointsTotal != 2 || pointsTotal != 3 || pointsTotal != 12 || pointsTotal != 7 || pointsTotal != 11 || pointsTotal != crapsPoint)
            //{
            if (Dice1 == 1)
            {
                clearDice1();
                pbDr11.Visible = true;
            }

                else if (Dice1 == 2)
                {
                    clearDice1();
                    pbDr12.Visible = true;
                }   

                else if (Dice1 == 3)
                {
                    clearDice1();
                    pbDr13.Visible = true;
                }

                else if (Dice1 == 4)
                {
                    clearDice1();
                    pbDr14.Visible = true;
                }

                else if (Dice1 == 5)
                {
                    clearDice1();
                    pbDr15.Visible = true;
                }

                else if (Dice1 == 6)
                {
                    clearDice1();
                    pbDr16.Visible = true;
                }

                // Beginning of Dice2 roll
                if (Dice2 == 1)
                {
                    clearDice2();
                    pbDr21.Visible = true;
                }

                else if (Dice2 == 2)
                {
                    clearDice2();
                    pbDr22.Visible = true;
                }

                else if (Dice2 == 3)
                {
                    clearDice2();
                    pbDr23.Visible = true;
                }

                else if (Dice2 == 4)
                {
                    clearDice2();
                    pbDr24.Visible = true;
                }

                else if (Dice2 == 5)
                {
                    clearDice2();
                    pbDr25.Visible = true;
                }

                else if (Dice2 == 6)
                {
                    clearDice2();
                    pbDr26.Visible = true;
                }

                // Points Calculation
                pointsTotal = Dice1 + Dice2;

                if (pointsTotal == 2 || pointsTotal == 3 || pointsTotal == 12)
                {
                    lblOutput.Text = ("Sorry you lose! You rolled: " + pointsTotal.ToString());
                }

                else if (pointsTotal == 7 || pointsTotal == 11)
                {
                    lblOutput.Text = ("Congradulations you win! You rolled: " + pointsTotal.ToString());
                }

                else
                {
                    crapsPoint = pointsTotal;
                    lblOutput.Text = ("You rolled:" + crapsPoint.ToString() + " please roll again.");
                }
            //}
        }

        // Trying a method doesn't seem to work.
        private void clearDice1()
        {
            pbDr11.Visible = false;
            pbDr12.Visible = false;
            pbDr13.Visible = false;
            pbDr14.Visible = false;
            pbDr15.Visible = false;
            pbDr16.Visible = false;
        }

        private void clearDice2()
        {
            pbDr21.Visible = false;
            pbDr22.Visible = false;
            pbDr23.Visible = false;
            pbDr24.Visible = false;
            pbDr25.Visible = false;
            pbDr26.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
