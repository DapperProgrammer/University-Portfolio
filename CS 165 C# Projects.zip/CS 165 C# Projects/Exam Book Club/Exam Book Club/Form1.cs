﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam_Book_Club
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            int numBooks; //initalize a variable named "numNooks" to be used in "
            numBooks = int.Parse(txtNumBooks.Text); // Turns the user inputed string into an integer

            if (numBooks == 0)
            {
                lblOutput.Text = ("You earned 0 points. ");
            }
            else if (numBooks == 1)
            {
                lblOutput.Text = ("You earned 5 points. ");
            }
            else if (numBooks == 2)
            {
                lblOutput.Text = ("You earned 15 points. ");
            }
            else if (numBooks == 3)
            {
                lblOutput.Text = ("You earned 30 points. ");
            }
            else if (numBooks >= 4)
            {
                lblOutput.Text = ("You earned 60 points. ");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
