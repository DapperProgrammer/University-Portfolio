﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Chapter07Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Opens the StudentAnswers.txt file
        StreamReader inputFile = File.OpenText("StudentAnswers.txt");

        // Creates a List object to hold the students answers
        List<string> answersList = new List<string>();

        private void PassOrFail(int score)
        {

            if (score >= 15)
            {
                lblOutput.Text = ("Pass");
            }
            else
            {
                lblOutput.Text = ("Did not pass");
            }
        }

        private void DisplayAnswers(List<string> aList)
        {
            bool correctAnswer;
            int rightAnswer, total;
            rightAnswer = 0;
            total = 0;

            foreach (string str in aList)
            {
                lblOutput.Text = (str);
            }
            if (aList[0] == "B")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[0] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[1] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[1] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[2] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[2] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[3] == "C")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[3] != "C")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[4] == "C")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[4] != "C")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[5] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[5] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[6] == "B")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[6] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[7] == "C")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[7] != "C")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[8] == "C")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[8] != "C")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[9] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[9] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[10] == "B")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[10] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[11] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[11] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[12] == "D")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[12] != "D")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[13] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[13] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[14] == "B")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[14] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[15] == "C")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[15] != "C")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[16] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[16] != "A")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[17] == "B")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[17] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[18] == "D")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[18] != "D")
            {
                correctAnswer = false;
                total = rightAnswer - 1;
            }
            if (aList[19] == "A")
            {
                correctAnswer = true;
                total = rightAnswer + 1;
            }
            else if (aList[19] != "B")
            {
                correctAnswer = false;
                total = rightAnswer - 1;

                // Calls the PassOrFail method passing in total for score
                PassOrFail(total);
            }
           

        }


        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Read the files contents
            while (!inputFile.EndOfStream)
            {
                // Reads each line in the file and adds it to the vaiable name
                // "answersList"
                answersList.Add(inputFile.ReadLine());
              
            }

            // Calls the DisplayAnswers method passing in answersList to aList
            DisplayAnswers(answersList);




        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
