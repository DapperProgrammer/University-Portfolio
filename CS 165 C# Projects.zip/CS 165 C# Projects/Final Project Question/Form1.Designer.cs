﻿namespace CS_165_Final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrimeOrEmirp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtListBoxPrime = new System.Windows.Forms.TextBox();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.lbPrime = new System.Windows.Forms.ListBox();
            this.btnAddNum = new System.Windows.Forms.Button();
            this.btnEnterFile = new System.Windows.Forms.Button();
            this.lbFile = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtPrimeOrEmirp
            // 
            this.txtPrimeOrEmirp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrimeOrEmirp.Location = new System.Drawing.Point(189, 16);
            this.txtPrimeOrEmirp.Name = "txtPrimeOrEmirp";
            this.txtPrimeOrEmirp.Size = new System.Drawing.Size(100, 31);
            this.txtPrimeOrEmirp.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter a number:";
            // 
            // btnEnter
            // 
            this.btnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.Location = new System.Drawing.Point(32, 75);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(88, 46);
            this.btnEnter.TabIndex = 2;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(345, 509);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 46);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(358, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(231, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter a number to see a list";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter a file name:";
            // 
            // txtListBoxPrime
            // 
            this.txtListBoxPrime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtListBoxPrime.Location = new System.Drawing.Point(606, 16);
            this.txtListBoxPrime.Name = "txtListBoxPrime";
            this.txtListBoxPrime.Size = new System.Drawing.Size(100, 31);
            this.txtListBoxPrime.TabIndex = 6;
            // 
            // txtFileName
            // 
            this.txtFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileName.Location = new System.Drawing.Point(189, 220);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(100, 31);
            this.txtFileName.TabIndex = 7;
            // 
            // lbPrime
            // 
            this.lbPrime.FormattingEnabled = true;
            this.lbPrime.Location = new System.Drawing.Point(362, 55);
            this.lbPrime.Name = "lbPrime";
            this.lbPrime.Size = new System.Drawing.Size(232, 147);
            this.lbPrime.TabIndex = 8;
            // 
            // btnAddNum
            // 
            this.btnAddNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNum.Location = new System.Drawing.Point(615, 75);
            this.btnAddNum.Name = "btnAddNum";
            this.btnAddNum.Size = new System.Drawing.Size(91, 46);
            this.btnAddNum.TabIndex = 9;
            this.btnAddNum.Text = "Add";
            this.btnAddNum.UseVisualStyleBackColor = true;
            this.btnAddNum.Click += new System.EventHandler(this.btnAddNum_Click);
            // 
            // btnEnterFile
            // 
            this.btnEnterFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnterFile.Location = new System.Drawing.Point(32, 429);
            this.btnEnterFile.Name = "btnEnterFile";
            this.btnEnterFile.Size = new System.Drawing.Size(86, 46);
            this.btnEnterFile.TabIndex = 10;
            this.btnEnterFile.Text = "Enter";
            this.btnEnterFile.UseVisualStyleBackColor = true;
            this.btnEnterFile.Click += new System.EventHandler(this.btnEnterFile_Click);
            // 
            // lbFile
            // 
            this.lbFile.FormattingEnabled = true;
            this.lbFile.Location = new System.Drawing.Point(32, 264);
            this.lbFile.Name = "lbFile";
            this.lbFile.Size = new System.Drawing.Size(241, 147);
            this.lbFile.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 608);
            this.Controls.Add(this.lbFile);
            this.Controls.Add(this.btnEnterFile);
            this.Controls.Add(this.btnAddNum);
            this.Controls.Add(this.lbPrime);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.txtListBoxPrime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPrimeOrEmirp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPrimeOrEmirp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtListBoxPrime;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.ListBox lbPrime;
        private System.Windows.Forms.Button btnAddNum;
        private System.Windows.Forms.Button btnEnterFile;
        private System.Windows.Forms.ListBox lbFile;
    }
}

