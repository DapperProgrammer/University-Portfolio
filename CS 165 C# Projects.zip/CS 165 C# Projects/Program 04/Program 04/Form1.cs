﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbWorkshop_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(lbWorkshop.Text);
        }

        private void lbLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(lbLocation.Text);
        }

        private void cbMember_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int RegFee = 0;
            int LodgeFee = 0;
            int Numdays = 0;
            int Total = 0;

            if (lbWorkshop.SelectedIndex == 0 || lbLocation.SelectedIndex == 0)
            {
                MessageBox.Show("Error invalid option.");
            }
            else
            {
                if (lbWorkshop.SelectedIndex == 1)
                {
                    Numdays = 3;
                    RegFee = 1000;
                }
                else if (lbWorkshop.SelectedIndex == 2)
                {
                    Numdays = 3;
                    RegFee = 800;
                }

                else if (lbWorkshop.SelectedIndex == 3)
                {
                    Numdays = 3;
                    RegFee = 1500;
                }

                else if (lbWorkshop.SelectedIndex == 4)
                {
                    Numdays = 5;
                    RegFee = 1300;
                }

                else if (lbWorkshop.SelectedIndex == 5)
                {
                    Numdays = 1;
                    RegFee = 500;
                }

                if (lbLocation.SelectedIndex == 1)
                {
                    LodgeFee = 150;
                }

                else if (lbLocation.SelectedIndex == 2)
                {
                    LodgeFee = 225;
                }

                else if (lbLocation.SelectedIndex == 3)
                {
                    LodgeFee = 175;
                }

                else if (lbLocation.SelectedIndex == 4)
                {
                    LodgeFee = 300;
                }

                else if (lbLocation.SelectedIndex == 5)
                {
                    LodgeFee = 175;
                }

                else if (lbLocation.SelectedIndex == 6)
                {
                    LodgeFee = 150;
                }
            }
            if (CbMem.Checked == false)
            {
                Total = lblOutput.Text = (LodgeFee.ToString() * Numdays.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
