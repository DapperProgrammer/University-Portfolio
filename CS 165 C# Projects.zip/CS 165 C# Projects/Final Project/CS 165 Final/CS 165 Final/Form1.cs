﻿// Calvin Tracy
// CS 165 01
// Final Project
// 2018/12/12
// Program to display primes and emirps, also accepts a file name with integers.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CS_165_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void primeNumberTest(int Pnum)
        {
            Boolean Prime = true;
            for (int i = 2; i < Pnum; i++)
            {
                // if Pnum divided by 2 is 0, it is not a prime.???????
                if (Pnum % i == 0)
                {
                    //MessageBox.Show(Pnum.ToString() + " " + "Not Prime");
                    //break;
                }
                //else
                //{
                   // MessageBox.Show(Pnum.ToString() + " " + "Prime");
                   // break;
                //}
            }

            // We set the Boolean value of "Prime" to True, so we execute the True statement first
            // If we set the Boolean value of "Prime" to False, we would execute the False statement first.
            // Therefore whatever comes after "if (Prime)" needs to be the statement corresponding to whichever
            // Boolean value we initialized first. 
            if (Prime)
            {
                MessageBox.Show(Pnum.ToString() + " " + "Prime");

            }
            else
            {
                MessageBox.Show(Pnum.ToString() + " " + "Not Prime");
            }
        }


        private void btnEnter_Click(object sender, EventArgs e)
        {
            int userNum, reverseNum;

            try
            {
                // Gets the number the user entered and converts it to an integer.
                userNum = int.Parse(txtPrimeOrEmirp.Text);
                //int reverseNum;

                // calls the function "primeNumberTest" and passes in userNum to "Pnum"
                primeNumberTest(userNum);

                // Calls the "ReverseUserNum" method passing in "userNum" to "revNum"
                reverseNum = reverseUserNum(userNum);
                //reverseUserNum(userNum);
                //primeNumberTest(reverseNum);
                primeNumberTest(reverseNum);

            }
            catch
            {
                MessageBox.Show("Error: Invalid data.");
            }
        }

        static int reverseUserNum(int revNum)
        {
            //int revNum = 0;
            string value;

            // Sets "Value" equal to the value of "revNum" in this case "Value"
            // is whatever number is passed into "revNum" while converting it to a String.
            value = revNum.ToString();
            string newNum = " ";

            for (int l = value.Length; l > 0; l--)
                newNum = newNum + value[l - 1];

            return revNum;
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddNum_Click(object sender, EventArgs e)
        {
            int listBoxNum ;
            try
            {
                listBoxNum = int.Parse(txtListBoxPrime.Text);
                
                // Adds user inputed data to the "lbPrime" list box. 
                lbPrime.Items.Add(listBoxNum);

                // Creates an Array of numbers equal to the data in "listBoxNum"
                var numbersArray = new int[listBoxNum];
                for (var i = 1; i <= listBoxNum; i++)
                    numbersArray[i - 1] = i;
                lbPrime.Items.Add(numbersArray);


            }
            catch
            {
                MessageBox.Show("Error: Invalid data.");
            }
           
        }

        private void btnEnterFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Declares a variable called "showNumbers" to hold a number each time we read
                // a line if text from the file. So if there are 5 numbers in the file, this variable
                // will be a reference to five numbers.
                string showNumbers, file;
                // Delcares a StreamReader variable/object called "inputFile" that is used to reference
                // the StreamReader Class and its methods.
                StreamReader inputFile;
                
                // Open the file, and assigns its contents to the StreamReader variable "inputFile"
                // This calls the "File.OpenText" method from the StreanReader Class, passing "My Numbers.txt" as
                // an argument.
                inputFile = File.OpenText("My Numbers.txt");

                // Clears anything currently in the ListBox
                lbFile.Items.Clear();

                // While the inputFile is not at the end of its contents
                while (!inputFile.EndOfStream)
                {
                    // Get a number
                    showNumbers = inputFile.ReadLine();
                    // Add the number to the ListBox
                    lbFile.Items.Add(showNumbers);
                }
                // Close the file
                inputFile.Close();
            }
            catch
            {
                MessageBox.Show("Error: File not found.");
            }
        }
    }
}
