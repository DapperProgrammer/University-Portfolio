﻿// Calvin Tracy
// CS 165 01
// Extra Credit Chapter 05
// 11/13/18
// Interest calculator

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Apologies for the un-completed assignment, I completely forgot about it until last night
        // I am embarrassed to turn this in however I will take any EC I can get. Thank you.
        private void btnAdd_Click(object sender, EventArgs e)
        {
            double balancedOwed;
            double interest;
            double principal;
            double payment;
            double remBalance;
            double userInput;
            double downPayment = 10;
            double interestRate = 12;
            double monthlyInterest = 5;

            lbCalcBox.Items.Add("Jan");
            lbCalcBox.Items.Add("Feb");
            lbCalcBox.Items.Add("Mar");
            lbCalcBox.Items.Add("Apr");
            lbCalcBox.Items.Add("May");
            lbCalcBox.Items.Add("Jun");
            lbCalcBox.Items.Add("Jly");
            lbCalcBox.Items.Add("Aug");
            lbCalcBox.Items.Add("Sep");
            lbCalcBox.Items.Add("Oct");
            lbCalcBox.Items.Add("Nov");
            lbCalcBox.Items.Add("Dev");

            userInput = double.Parse(txtPurchase.Text);
            balancedOwed = userInput * downPayment * interestRate * monthlyInterest * 12;


        }

        private void lbCalcBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
