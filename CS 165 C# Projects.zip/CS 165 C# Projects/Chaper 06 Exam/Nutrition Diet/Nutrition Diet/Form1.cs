﻿// Calvin Tracy
// CS 165 01
// Chapter 06 Exam
// 11/20/18

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nutrition_Diet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int FatCalories(int gramsFat)
        {
            return gramsFat * 9;
        }

        private int CarbCalories(int gramsCarb)
        {
            return gramsCarb * 4;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int gramsFat, gramsCarb, totalFatCal, totalCarbsCal;

            // gets user entered data from the txtbox and turns it into an integer
            gramsFat = int.Parse(txtGrams.Text);
            gramsCarb = int.Parse(txtCarbs.Text);

            // Passes in gramsFat and gramsCarb that are now equal to the user data
            // and passes them into the FatCalories and CarbCalories methods.
            totalFatCal = FatCalories(gramsFat);
            totalCarbsCal = CarbCalories(gramsCarb);

            // Converts the integers gotten from the methods calculations to a string.
            lblFatCal.Text = totalFatCal.ToString();
            lblCarbsCal.Text = totalCarbsCal.ToString();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
