﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_02_CH3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Tells the program what kind of variable numOne, numTwo, and total, will be.
                // "double" is a float that can accomidate more decimal places
                double numOne;
                double numTwo;
                double total;

                // Converts the txt.Num1, and txt.Num2 into a float
                numOne = double.Parse(txtNum1.Text);
                numTwo = double.Parse(txtNum2.Text);

                // Adds numOne and numTwo together and outouts the answer to the lblOutput box, converting it to a string. 
                total = numOne + numTwo;
                lblOutput.Text = total.ToString();
            }
            catch
            {
                MessageBox.Show("Invalid data was entered.");
            }
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            try
            {
                double numOne;
                double numTwo;
                double total;

                numOne = double.Parse(txtNum1.Text);
                numTwo = double.Parse(txtNum2.Text);

                total = numOne - numTwo;
                lblOutput.Text = total.ToString();
            }
            catch
            {
                MessageBox.Show("Invalid data was entered.");
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            try
            {
                double numOne;
                double numTwo;
                double total;

                numOne = double.Parse(txtNum1.Text);
                numTwo = double.Parse(txtNum2.Text);

                total = numOne * numTwo;
                lblOutput.Text = total.ToString();
            }
            catch
            {
                MessageBox.Show("Invalid data was entered.");
            }
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblOutput_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
