﻿namespace Program_02_CH3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Missouri = new System.Windows.Forms.Button();
            this.Kansas = new System.Windows.Forms.Button();
            this.NorthCarolina = new System.Windows.Forms.Button();
            this.Georgia = new System.Windows.Forms.Button();
            this.Alabama = new System.Windows.Forms.Button();
            this.Flordia = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.abbreviationLabel = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Missouri
            // 
            this.Missouri.Location = new System.Drawing.Point(24, 12);
            this.Missouri.Name = "Missouri";
            this.Missouri.Size = new System.Drawing.Size(92, 33);
            this.Missouri.TabIndex = 0;
            this.Missouri.Text = "Missouri";
            this.Missouri.UseVisualStyleBackColor = true;
            this.Missouri.Click += new System.EventHandler(this.Missouri_Click);
            // 
            // Kansas
            // 
            this.Kansas.Location = new System.Drawing.Point(157, 12);
            this.Kansas.Name = "Kansas";
            this.Kansas.Size = new System.Drawing.Size(98, 33);
            this.Kansas.TabIndex = 1;
            this.Kansas.Text = "Kansas";
            this.Kansas.UseVisualStyleBackColor = true;
            this.Kansas.Click += new System.EventHandler(this.Kansas_Click);
            // 
            // NorthCarolina
            // 
            this.NorthCarolina.Location = new System.Drawing.Point(24, 68);
            this.NorthCarolina.Name = "NorthCarolina";
            this.NorthCarolina.Size = new System.Drawing.Size(92, 30);
            this.NorthCarolina.TabIndex = 2;
            this.NorthCarolina.Text = "North Carolina";
            this.NorthCarolina.UseVisualStyleBackColor = true;
            this.NorthCarolina.Click += new System.EventHandler(this.NorthCarolina_Click);
            // 
            // Georgia
            // 
            this.Georgia.Location = new System.Drawing.Point(157, 68);
            this.Georgia.Name = "Georgia";
            this.Georgia.Size = new System.Drawing.Size(98, 30);
            this.Georgia.TabIndex = 3;
            this.Georgia.Text = "Georgia";
            this.Georgia.UseVisualStyleBackColor = true;
            this.Georgia.Click += new System.EventHandler(this.Georgia_Click);
            // 
            // Alabama
            // 
            this.Alabama.Location = new System.Drawing.Point(24, 120);
            this.Alabama.Name = "Alabama";
            this.Alabama.Size = new System.Drawing.Size(92, 32);
            this.Alabama.TabIndex = 4;
            this.Alabama.Text = "Alabama";
            this.Alabama.UseVisualStyleBackColor = true;
            this.Alabama.Click += new System.EventHandler(this.Alabama_Click);
            // 
            // Flordia
            // 
            this.Flordia.Location = new System.Drawing.Point(157, 120);
            this.Flordia.Name = "Flordia";
            this.Flordia.Size = new System.Drawing.Size(98, 32);
            this.Flordia.TabIndex = 5;
            this.Flordia.Text = "Flordia";
            this.Flordia.UseVisualStyleBackColor = true;
            this.Flordia.Click += new System.EventHandler(this.Flordia_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Click the states to see their abbreviation!";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // abbreviationLabel
            // 
            this.abbreviationLabel.Location = new System.Drawing.Point(97, 196);
            this.abbreviationLabel.Name = "abbreviationLabel";
            this.abbreviationLabel.Size = new System.Drawing.Size(84, 21);
            this.abbreviationLabel.TabIndex = 7;
            this.abbreviationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(100, 235);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 8;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.abbreviationLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Flordia);
            this.Controls.Add(this.Alabama);
            this.Controls.Add(this.Georgia);
            this.Controls.Add(this.NorthCarolina);
            this.Controls.Add(this.Kansas);
            this.Controls.Add(this.Missouri);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Missouri;
        private System.Windows.Forms.Button Kansas;
        private System.Windows.Forms.Button NorthCarolina;
        private System.Windows.Forms.Button Georgia;
        private System.Windows.Forms.Button Alabama;
        private System.Windows.Forms.Button Flordia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label abbreviationLabel;
        private System.Windows.Forms.Button exitBtn;
    }
}

