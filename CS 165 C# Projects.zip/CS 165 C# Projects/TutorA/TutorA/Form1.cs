﻿// Calvin Tracy
// CS 165 01
// Chapter 05 Exam

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TutorA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            int num1;
            int num2;
            int answer;
            Random rand = new Random();
            num1 = rand.Next(100, 501);
            lblNumber1.Text = num1.ToString();

            num2 = rand.Next(100, 501);
            lblNumber2.Text = num2.ToString();
            answer = num1 + num2;
            //lbloutput.Text = answer.ToString();


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;
            int answer;
            int userAnswer;
            answer = int.Parse(lblNumber1.Text) + int.Parse(lblNumber2.Text); // Get nums from the form

            userAnswer = int.Parse(txtAnswser.Text);

            if (userAnswer == answer)
            {
                MessageBox.Show("Correct!");
                txtAnswser.Text = " ";
            }
            else
            {
                MessageBox.Show("Sorry try again!");
                txtAnswser.Text = " ";
            }
           
            Random rand = new Random();
            num1 = rand.Next(100, 501);
            lblNumber1.Text = num1.ToString();

            num2 = rand.Next(100, 501);
            lblNumber2.Text = num2.ToString();
            answer = num1 + num2;
            lbloutput.Text = answer.ToString();


           
        }
    }
}
