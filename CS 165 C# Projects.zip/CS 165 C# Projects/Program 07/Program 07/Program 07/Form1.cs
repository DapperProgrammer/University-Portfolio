﻿// Calvin Tracy
// CS 165 01
// Program 07
// 12/06/18
// Program to find popular baby names from user input. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Program_07
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Open names .txt file and assign them to "inputfile" objects of the StreamReader Class.
        StreamReader inputFileBoy = File.OpenText("BoyNames.txt");
        StreamReader inputFileGirl = File.OpenText("GirlNames.txt");

        // Creates a "List" object referenced by the variables "nameListBoy" and "nameListGirl" to hold the boy and girl names.
        // "new List<string>();" Tells the list that it can hold strings.
        List<string> nameListBoy = new List<string>();
        List<string> nameListGirl = new List<string>();

        private void btnCheck_Click(object sender, EventArgs e)
        {
            int positionB, positionG;

            // While the boy file is not at the end of its contents
            while (!inputFileBoy.EndOfStream)
            {
                // Read a line and add its contents to the nameListBoy
                nameListBoy.Add(inputFileBoy.ReadLine());
            }
            // While the girl file is not at the end of its contents
            while (!inputFileGirl.EndOfStream)
            {
                // Read a line and add its contents to the nameListGirl
                nameListGirl.Add(inputFileGirl.ReadLine());
            }

            // Sets the integer "position" variable equal to the string value of "txtBoyName" text box
            // ".Text" gets the string value associated with the text box control.
            // "IndexOF" is a method that finds the index of the specified data, in this case a name.
            positionB = nameListBoy.IndexOf(txtBoyName.Text);
            if (positionB != -1)
            {
                MessageBox.Show("Yes that was a popular boy name!");
            }
            else
            {
                MessageBox.Show("That boy name is not on our list.");
            }
            positionG = nameListGirl.IndexOf(txtGirlName.Text);
            if (positionG != -1)
            {
                MessageBox.Show("Yes that was a popular girl name!");
            }
            else
            {
                MessageBox.Show("That girl name is not on our list.");
            }
                
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
