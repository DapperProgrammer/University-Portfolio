﻿// Label 8 is "Parts"

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automotive_Services
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private double findOilLubeCost()
        {
            double total = 0;
            if (chkOil.Checked) // if the oil checkbox is checked
                total = total + 26.00;
            if (chkLube.Checked)
                total = total + 18.00;
            return total; // adds everything together
        }

        private double findFlushesCost()
        {
            double total = 0;
            if (chkRadiator.Checked)
                total = total + 30.00;
            if (chkTransmission.Checked)
                total = total + 80.00;
            return total;
        }

        private double findMiscCost()
        {
            double total = 0;
            if (chkInspection.Checked)
                total = total + 15.00;
            if (chkMuffler.Checked)
                total = total + 100.00;
            if (chkRotation.Checked)
                total = total + 20.00;
            return total;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double oilLubeCost, flushCost, miscCost, partsCost, laborCost, tax;
            double totalCharges, totalService;
            
            
            // Setting variables equal to their methods
            oilLubeCost = findOilLubeCost();
            flushCost = findFlushesCost();
            miscCost = findMiscCost();

            // Converts the text in the "txtParts" textbox to a double
            partsCost = double.Parse(txtParts.Text);
            // Converts the text in the "txtLabor" textbox to a double
            laborCost = double.Parse(txtLabor.Text);

            tax = partsCost * 0.06;
            totalService = oilLubeCost + flushCost + miscCost + laborCost;
            totalCharges = totalService + partsCost + tax;

            lblServiceLabor.Text = totalService.ToString("c");
            lblParts.Text = partsCost.ToString("c");
            lblTax.Text = tax.ToString("c");
            lblTotal.Text = totalCharges.ToString("c");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
