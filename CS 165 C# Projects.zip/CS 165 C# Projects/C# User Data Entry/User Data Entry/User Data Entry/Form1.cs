﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace User_Data_Entry
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            try
            {   
                // Initalizes the "StreamWriter" Class with "outputFile" attatched to it as a reference Variable.
                // This allows us to use the methods in the "StreamWriter" Class whenever we use "outputFile".
                // The "StreamWriter" Class allows us to WRITE data to a file.
                // "outputFile" is defined as a "StreamWriter" Object. Much like if we had
                // "int annualTotal;" annualTotal would be an "integer" Object.
                StreamWriter outputFile;

                // Calls the method "File" from "System.IO"
                // Also calls the "CreateText" method from "StreamWriter" Class
                outputFile = File.CreateText(@"C:\C# Files\C# txt Files\userData.txt");

                // .Text gets or sets the text associated with the textbox control. 
                // In this case the ".Text" method is GETTING the text from the "txtData" box 
                // and writing it to the "userData.txt" file which is stored in the outputFile variable.
                outputFile.WriteLine(txtData.Text);

                // Closes the file
                outputFile.Close();

                // Displays a message letting the user know the data was entered successfully. 
                MessageBox.Show("Data entry successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
