﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automible_Cost
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            decimal loan;
            decimal insurance;
            decimal gas;
            decimal oil;
            decimal tires;
            decimal maintenance;
            decimal monthlyTotal;
            decimal annualTotal;

            // Convert variables from string format to decimals
            loan = decimal.Parse(txtLoan.Text);
            insurance = decimal.Parse(txtInsurance.Text);
            gas = decimal.Parse(txtGas.Text);
            oil = decimal.Parse(txtOil.Text);
            tires = decimal.Parse(txtTires.Text);
            maintenance = decimal.Parse(txtMaintenance.Text);

            // Performs mathmatical operations for given variables
            monthlyTotal = loan + insurance + gas + oil + tires + maintenance;
            annualTotal = monthlyTotal * 12;

            // Converts the numberic values of the variables to a string
            // "C" is C# for "currency"
            lblMonthlyCost.Text = monthlyTotal.ToString("C");
            lblAnnualCost.Text = annualTotal.ToString("C");

        }
    }
}
