class Clock:
    def __init__(self, hour, minute, second):
        self.hour = hour #assigns user inputed data to hour and assigns the value of 'hour' to 'self.hour' 
        self.minute = minute
        self.second = second
	  
    def set_hour(self, hour):
        self.hour = hour
	  
    def get_hour(self):
        clock_hour = self.hour #Assigns the value of 'self.hour' to 'clock_hour'
        if self.hour >= 0 and self.hour <= 23:
            return clock_hour
        else:
             print('Error invalid hour!')
	  
    def set_minute(self, minute):
        self.minute = minute
	  
    def get_minute(self):
        clock_minute = self.minute
        if self.minute >= 0 and self.minute <= 59:
            return clock_minute
        else:
            print('Error invalid minute!')
	  
    def set_second(self, second):
        self.second = second
	  
    def get_second(self):
        clock_second = self.second
        if self.second >= 0 and self.second <= 59:
            return clock_second
        else:
            print('Error invalid second!')
		  
    def increment_method(self ):
	  #def increment_method(self,hour, minute, second ):
        self.second = self.second + 1
        if self.second > 59:
            self.second == 0
            self.minute = self.minute + 1
        if self.minute > 59:
            self.minute == 0
            self.hour = self.hour + 1
        if self.hour > 23:
            self.hour == 0
        else:
            print('stuff.')


def main():
    user_input =  Clock (int(input('Enter hour: ')),int(input('Enter minute: ')), int(input('Enter second: ')))
  
    print()
  
    print('Hour: ', user_input.get_hour(), 'Minute: ', user_input.get_minute(), 'Second: ', user_input.get_second())
  
  #Clock.increment_method (user_input.get_hour(), user_input.get_minute(), user_input.get_second())
    user_input.increment_method ()
    print('Hour: ', user_input.get_hour(), 'Minute: ', user_input.get_minute(), 'Second: ', user_input.get_second())
main()

#why did self.get_minute work?