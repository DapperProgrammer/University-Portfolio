#Calvin Tracy
#CS 22 02
#Assignment Extra Credit Assignment 01
#Due Date: 3/5/2018
#Date Turned in: 3/5/2018
#Class with a clock time and alarm


from ClockClass import *

def main():
  user_input = Clock(int(input('Enter hour: ')),int(input('Enter minute: ')), int(input('Enter second: ', )))
  #Creates 'user_input' as an object of the Class 'Clock'
  print()
  print('HH: ', user_input.get_hour(), 'MM: ', user_input.get_minute(), 'SS: ', user_input.get_second())
  
  user_input.increment_method() #calls the increment method
  #print('HH: ', user_input.get_hour(), 'MM: ', user_input.get_minute(), 'SS: ', user_input.get_second())
  
  user_input.__str__() #Calls the 'str' method to print the input out as a string instead of integers
  
main()
