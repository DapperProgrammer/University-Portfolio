class Clock:
  def __init__(self, hour, minute, second):
    self.hour = hour #assigns user inputed data to hour and assigns the value of 'hour' to 'self.hour' 
    self.minute = minute
    self.second = second
  
  def set_hour(self, hour):
    self.hour = hour
  
  def get_hour(self):
    clock_hour = self.hour #Assigns the value of 'self.hour' to 'clock_hour'
    if self.hour >= 0 and self.hour <= 23:
      return clock_hour
    else:
      print('Error invalid hour!')
  
  def set_minute(self, minute):
    self.minute = minute
  
  def get_minute(self):
    clock_minute = self.minute
    if self.minute >=0 and self.minute <= 59:
      return clock_minute
    else:
      print('Error invalid minute!')
  
  def set_second(self, second):
    self.second = second
  
  def get_second(self):
    clock_second = self.second
    if self.second >=0 and self.second <= 59:
      return clock_second
    else:
      print('Error invalid second!')
      
  def increment_method(self ):
    self.second = self.second + 1
    if self.second > 59:
      self.second = 0
      self.minute = self.minute + 1
    if self.minute > 59:
      self.minute = 0
      self.hour = self.hour + 1
    if self.hour > 23:
      self.hour = 0
      
class Alarm(Clock):
  def __init__(self, hour, minute, second):
    Clock.__init__(self, hour, minute, second)
    self.alarm_time
    self.alarm_on_off
  
  def alarm_time():
    clock_alarm = int(input('Set alarm:'))
    return clock_alarm
    
  def alarm_on_off():
    alarm_on = True
    alarm_off = False
    if alarm_time >= 0000 and alarm_time <= 235959:
      alarm_on = True
    else:
      alarm_on = alarm_off
    



def main():
  user_input = Clock(int(input('Enter hour: ')),int(input('Enter minute: ')), int(input('Enter second: ', )))
  #Creates 'user_input' as an object of the Class 'Clock'
  print()
  print('HH: ', user_input.get_hour(), 'MM: ', user_input.get_minute(), 'SS: ', user_input.get_second())
  
  user_input.increment_method() #calls the increment method
  print('HH: ', user_input.get_hour(), 'MM: ', user_input.get_minute(), 'SS: ', user_input.get_second())
  
  user_input.alarm_time()
  
main()
