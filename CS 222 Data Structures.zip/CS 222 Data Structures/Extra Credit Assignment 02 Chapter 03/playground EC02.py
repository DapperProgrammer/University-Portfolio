class Node:
  def __init__(self, item = None):
    self.item = item
    self.next = None #Sets up the next node
    self.previous = None


class Queue:
    def __init__(self):
        self.items = []#Initalize empty list called 'items'

    def isEmpty(self):
        return self.items == []#Check to see if list is empty

    def enqueue(self,item):
        self.items.insert(0, item)#Add 'item' at index '0'

    def dequeue(self):
        return self.items.pop()#Remove item from the front of queue

    def size(self):
        return len(self.items)#Return how many items are in the queue list
