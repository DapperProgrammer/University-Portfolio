#Calvin Tracy
#Class and Section: CS 222 02
#Assignment: Extra Credit Assignment 02
#Due Date: 4/18/18
#Date Turned in:
#Program Description: Queue for linked lists Node


from node import Node

class Queue (object):
  def __init__(self, root = None):
    self.root = root#Pointer to find the 'root' node
    self.size = 0

  def get_size(self):
    return self.size#returns the size 

  def enqueue(self, data):#Passes in 'data'
    new_node = Node (data, self.root)#Creates 'new_node' passing in 'data'
    self.root = new_node#Set self.root now equals 'new_node'
    self.size = self.size + 1 #increment size by 1

  def dequeue(self, data):#pass in data to remove
    this_node = self.root#this_node = root node
    prev_node = None#if data not in the list returns 'None'

    while this_node is not None:#while we are not at the end of the list
      if this_node.get_data() == data:#if this nodes data is == to the data we are looking for, then proceed to the 'if' statement below.
        if prev_node is not None:#if we aren't in the root node
          prev_node.set_next(this_node.get_next())#set previous node to
        else:
          self.root = this_node.get_next()
        self.size -= 1
        return True	# data removed
      else:
        prev_node = this_node#increment prev_node to this_node
        this_node = this_node.get_next()#increment this_node to the next_node
    return False  #data not found

  def find(self, data):
    this_node = self.root
    while this_node is not None:
      if this_node.get_data() == data:
        return data
      else:
        this_node = this_node.get_next()
    return None

def main():
  
  myList = Queue()
  myList.enqueue(5)
  myList.enqueue(8)
  myList.enqueue(12)
  print("Size = ", str(myList.get_size()))
  myList.dequeue(8)
  print("Size = ", str(myList.get_size()))
  print(myList.dequeue(12))
  print("Size = ", str(myList.get_size()))
  print(myList.find(5))

main()


