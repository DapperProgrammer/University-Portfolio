from stack import Stack

def parChecker(symbolString):
    s = Stack() #Creates 's' as an object of the 'Stack' class
    balanced = True
    index = 0 #Starts at position '0'
    while index < len(symbolString) and balanced: #While 'index' is less than the length of 'symbolString'
        symbol = symbolString[index]
        if symbol in "([{": #if the symbol is in "([{"
            s.push(symbol) #Calls the method 'push' from Stack Class
        else:
            if s.isEmpty(): #Calls the method 'isEmpty' from Stack Class
                balanced = False
            else:
                top = s.pop() #Calls the method 'pop' from Stack Class, removes stack
                if not matches(top, symbol): #Check if top and symbol match
                    balanced = False #if they dont balanced = False
                    
        index +=1 #Adds 1 to the position
    if balanced and s.isEmpty():
        return True
    else:
        return False
    
def matches(opened, closed):
    opens = "([{"
    closes = ")]}"
    return opens.index(opened) == closes.index(closed)

def main():
    symbol = "([{})"
    print(parChecker(symbol)) #Puts the 'symbol' value into 'symbolString' in 'parChecker'
    
main()
