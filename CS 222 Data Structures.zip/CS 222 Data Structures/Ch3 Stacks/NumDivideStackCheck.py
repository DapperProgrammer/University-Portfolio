from stack import Stack

def divideBy2(decNumber):
    remStack = Stack() #object of Stack
    while decNumber > 0:
        rem = decNumber % 2 #calculate remainder of the number % == 'mod'
        remStack.push(rem)
        decNumber = decNumber // 2 #integer division
    binString = ""
    while not remStack.isEmpty(): #while we have something in the stack, keep going
        binString = binString + str(remStack.pop()) #string representation
    return binString

def main():
    num = 233
    print(divideBy2(num))

main()
