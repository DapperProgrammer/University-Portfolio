from stack import Stack

def baseConverter (decNumber, base):
    digits = "0123456789ABCDEF"
    remStack = Stack() #object of Stack
    while decNumber > 0:
        rem = decNumber % base #calculate remainder of the number % == 'mod'
        remStack.push(rem)
        decNumber = decNumber // base #integer division
    newString = ""
    while not remStack.isEmpty(): #while we have something in the stack, keep going
        newString = newString + digits[(remStack.pop())] #rem is the index for 'digits' string
    return newString

def main():
    dec = int(input("Enter a decimal number:"))
    while dec >= 0:
        base = int(input("enter base:"))
        print(baseConverter(dec, base)) #Passes in 'dec' and 'base'
        dec = int(input("Enter a decimal number:"))

main()
