class Stack:
    def __init__(self):
        self.items = [] #empty list

    def isEmpty(self):
        return self.items == [] #return an empty list

    def push(self, item):
        self.items.append(item) #add an item to the list

    def pop(self):
        return self.items.pop() #remove an item from the list

    def peek(self):
        return self.items[len(self.items) - 1]

    def size(self):
        return len(self.items) #Prints the Stack list
    
