from stack import Stack
import string

def infixToPostfix(infixexpr): #pass in infixexpr
    prec = {}
    prec['*'] = 3 #Presadence order
    prec['/'] = 3
    prec['+'] = 2
    prec['-'] = 2
    prec['('] = 1
    opStack = Stack()#Creates 'opStack' as an object of the Stack Class
    postfixList = [] #Empty list
    tokenList = infixexpr.split()
    for token in tokenList:
        if token in string.ascii_uppercase: #if token is a letter
            postfixList.append(token) #add 'token'
        elif token == '(': #if token is a (
            opStack.push(token) #push onto stack
        elif token == ')': #if token is a )
            topToken = opStack.pop() #remove it
            while topToken != '(':
                postfixList.append(topToken)
                topToken = opStack.pop()
        else:
            while (not opStack.isEmpty()) and \
                  (prec[opStack.peek()] >= prec[token]):
                postfixList.append(opStack.pop()) #Add to list
            opStack.push(token)
        while not opStack.isEmpty():
            postfixList.append(opStack.pop())
        return ' '.join(postfixList) #Join all values in 'postfixList' to one string and seperate them by a space

def main():
    exp = '( ( ( A + B ) * C ) - ( ( D - E ) * ( F + G ) ) )'
    print(infixToPostfix(exp))
main()
