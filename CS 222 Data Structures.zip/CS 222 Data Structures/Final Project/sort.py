a = [3,4,2,6,8,1,9]
print("unsorted list:",a)
print("temp sorted list:",sorted(a))
print("After sort:",a)
print("Perm sorted list:",a.sort())
print("After sort:",a)
