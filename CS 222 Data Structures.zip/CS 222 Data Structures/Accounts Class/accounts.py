class SavingsAccount:
    def __init__(self, accountNum, intRate, bal):
        self.accountNum = accountNum
        self.interestRate = intRate
        self.balance = bal

    def setAccountNum(self, accountNum):
        self.accountNum = accountNum

    def setInterestRate(self, intRate):
        self.interestRate = intRate

    def setBalance(self, bal):
        self.balance = bal

    def getAccountNum(self):
        return self.accountNum

    def getInterestRate(self):
        return self.interestRate

    def getBalance(self):
        return self.balance

    def deposit(self, amount):
        if amount <= 0:
            print('Amount must be greater than $0.')
        else:
            self.balance += amount

    def withdraw(self, amount):
        if amount > self.balance:
            print('Cannot withdraw more than balance.')
        else:
            self.balance -= amount

    def calcInterest(self):
        interest = self.balance * self.interestRate
        self.balance += interest
        return interest

    def __str__(self):
        msg = 'Account number:' + str(self.getAccountNum())#converted interest to a string
        msg += "\nInterest rate: " + str(self.getInterestRate())
        msg += "\nBalance: $" + format(self.getBalance(), ",.2f")
        return msg

class CD(SavingsAccount):
    def __init__(self, accountNum, intRate, bal, matDate):
        SavingsAccount.__init__(self, accountNum, intRate, bal)
        self.maturityDate = matDate

    def setMaturityDate(self, matDate):
        self.maturityDate = matDate

    def getMaturityDate(self):
        return self.maturityDate

    def __str__(self):
        msg = SavingsAccount.__str__(self) #calls savings account str passing self in, self is the object that calls the CD str
        msg += "\nMaturity date: " + self.getMaturityDate()
        return msg
    
