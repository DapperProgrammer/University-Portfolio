from accounts import *

def main():
    print("Enter the following data for a savings account.")
    acctNum = input("Account Number: ")
    intRate = float(input("Interest Rate: "))
    balance = float(input("Balance: "))

    savings = SavingsAccount(acctNum, intRate, balance)
    print("Savings Account")
    print("---------------")
    print(savings)#calls str from savings account
    print()
    
    print("Enter the following data for a CD.")
    acctNum = input("Account Number: ")
    intRate = float(input("Interest Rate: "))
    balance = float(input("Balance: "))
    maturity = input("Maturity date: ")

    cd = CD(acctNum, intRate, balance, maturity)
    savings.deposit(500)
    savings.withdraw(100)
    interest = savings.calcInterest()
    print('Savings Interest: ', interest)

    print("Here is the data you entered:")
    print()
    print("Savings Account")
    print("---------------")
    print(savings)#calls str from savings account
    interest = cd.calcInterest()
    print('CD Interest: ', interest)
    print()
    print("CD")
    print("---------------")
    print(cd)

main()
