import random
def bubbleSort(alist):
    exchanges = True
    passnum = len(alist) - 1
    while passnum > 0 and exchanges: #while 'passnum' is less than 0 and True ('exchanges')
        exchanges = False
        for i in range(passnum):
            if alist[i] > alist[i + 1]:
                exchanges = True
                temp = alist[i]
                alist[i] = alist[i + 1]
                alist[i + 1] = temp
        passnum -= 1

def printList(alist):
    count = 0
    for x in range(len(alist)):
        
        if count % 10 == 0:
            print()
        print("%4d" % alist[x], end = " ")
        count += 1

def main():
    lyst = []
    for x in range(10000):
        lyst.append(x)
    random.shuffle(lyst)#Shuffles the list in random order
    #printList(lyst)
    #print()
    bubbleSort(lyst)
    #printList(lyst)

main()
    
