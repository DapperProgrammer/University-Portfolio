import random
def bubbleSort(alist):
    for passnum in range(len(alist) - 1, 0, -1):
        exchanges = False
        for i in range(passnum):
            if alist[i] > alist[i + 1]:
                temp = alist[i]
                alist[i] = alist[i + 1]
                alist[i + 1] = temp

def printList(alist):
    count = 0
    for x in range(len(alist)):
        
        if count % 10 == 0:
            print()
        print("%4d" % alist[x], end = " ")
        count += 1

def main():
    lyst = []
    for x in range(1000):
        lyst.append(x)
    random.shuffle(lyst)
    printList(lyst)
    print()
    bubbleSort(lyst)
    printList(lyst)

main()
    
