import random

def shellSort(alist):
    sublistCount = len(alist) // 2
    while sublistCount > 0:
        for startPosition in range(sublistCount):
            gapInsertionSort(alist, startPosition, sublistCount)
        #print("After increment of size", sublistCount, "the list is")
        #printList(alist)
        sublistCount = sublistCount // 2

def gapInsertionSort(alist, start, gap):
    for i in range(start + gap, len(alist), gap):
        currentValue = alist[i]
        position = i
        while position >= gap and \
              alist[position - gap] > currentValue:
            alist[position] = alist[position - gap]
            position = position - gap
        alist[position] = currentValue

def printList(alist):
    count = 0
    for x in range(len(alist)):
        
        if count % 10 == 0:
            print()
        print("%4d" % alist[x], end = " ")
        count += 1

def main():
    lyst = []
    for x in range(100000):
        lyst.append(x)
    random.shuffle(lyst)
    #printList(lyst)
    #print()
    shellSort(lyst)
    #printList(lyst)

main()
    
