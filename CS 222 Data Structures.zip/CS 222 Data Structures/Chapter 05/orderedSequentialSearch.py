import random
def orderedSequentialSearch(alist, item):#Pass in the list, and item looking for
    pos = 0
    found = False
    stop = False
    count = 0
    while pos < len(alist) and not found and not stop:
        count += 1
        if alist[pos] == item:#if position is == to the item
            found = True
        else:
            if alist[pos] > item:#if position is != to item
                stop = True
            else:
                pos += 1
    return found, count

def main():
    lyst = []
    for x in range(0, 1000000, 2):# 0 through a million 2 at a time
        lyst.append(x)
    #random.shuffle(lyst)
    search, count = orderedSequentialSearch(lyst, 675345)
    print("Was the value found", search)
    print("How many comparisons?", count)
    

main()
