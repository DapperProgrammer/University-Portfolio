import random
import time
def sequentialSearch(alist, item):#Pass in the list, and item looking for
    pos = 0
    found = False
    count = 0
    while pos < len(alist) and not found:
        count += 1
        if alist[pos] == item:
            found = True
        else:
            pos += 1
    return found, count

def main():
    lyst = []
    number = int(input("Enter number of values: "))#Ask for a number of integers
    for x in range(number):#for however many numbers in 'number'
        lyst.append(x)#add them to the 'lyst;
    random.shuffle(lyst)
    searchValue = int(input("Enter number to search for: "))#what num to look for within that range
    start = time.time()#starts timing the program
    search, count = sequentialSearch(lyst, searchValue)#pass in 'lyst' and 'searchValue'
    end = time.time()#ends the timing of the program
    print("Was the value found", search)
    print("How many comparisons?", count)
    print("Time to complete: ", end - start)
    

main()
