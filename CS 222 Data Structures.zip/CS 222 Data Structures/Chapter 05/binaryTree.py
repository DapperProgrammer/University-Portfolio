#see pg 242
#cant move r. r has to point to the beginning
#curent = r

class BinaryTree:
    def __init__(self, root_obj):#Passes in a root object which will be any value we want
        self.key = root_obj
        self.left_child = None
        self.right_child = None

    def insert_left(self, new_node):
        if self.left_child == None:
            self.left_child = BinaryTree(new_node)#Calls BinaryTree which creates a 'new_node' which goes into the 'root_obj'
        else:
            t = BinaryTree(new_node)#Creates a new tree
            t.left = self.left_child #t.left is equal to self.left_child
            self.left_child = t#Points to 't'

    def insert_right(self, new_node):
        if self.right_child == None:
            self.right_child = BinaryTree(new_node)#Calls BinaryTree which creates a 'new_node' which goes into the 'root_obj'
        else:
            t = BinaryTree(new_node)#Creates a new tree
            t.right = self.right_child #t.left is equal to self.left_child
            self.right_child = t#Points to 't'

    def get_right_child(self):
        return self.right_child

    def get_left_child(self):
        return self.left_child

    def set_root_value(self, root_obj):
        self.key = root_obj

    def get_root_value(self):
        return self.key

def main():
    r = BinaryTree('a')#Creates a node with a stored into it with a left and right child
    print(r.get_root_value())
    print(r.get_left_child())
    r.insert_left('b')#Sets a new noded called b that stores b
    print(r.get_left_child().get_root_value())
    r.insert_right('c')#inserts a new noded called c that stores c
    print(r.get_right_child().get_root_value())
    r.get_right_child().set_root_value('hello')
    print(r.get_right_child().get_root_value())
    
main()
