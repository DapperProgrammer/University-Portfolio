import random

def insertionSort(alist):
    for index in range(1, len(alist)):
        currentValue = alist[index]
        position = index
        while position > 0 and alist[position - 1] > currentValue:
            alist[position] = alist[position - 1]
            position = position - 1
        alist[position] = currentValue

def printList(alist):
    count = 0
    for x in range(len(alist)):
        
        if count % 10 == 0:
            print()
        print("%4d" % alist[x], end = " ")
        count += 1

def main():
    lyst = []
    for x in range(10000):
        lyst.append(x)
    random.shuffle(lyst)
    #printList(lyst)
    #print()
    insertionSort(lyst)
    #printList(lyst)

main()
    
