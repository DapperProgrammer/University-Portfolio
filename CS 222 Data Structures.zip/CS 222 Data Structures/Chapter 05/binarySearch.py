import random
def binarySearch(alist, item):
    first = 0 #
    last = len(alist) - 1 # 10 - 1 is 9
    found = False #
    count = 0  
    while first <= last and not found: #and not found, if found ==  true the loop stops
        count += 1 #count = count + 1
        midpoint = (first + last) // 2 #integer division 2 (9/2 = 4)
        if alist[midpoint] == item: #mid point is 24, if it is == to our item
            found = True
        else:
            if item < alist[midpoint]: #if item is less than 24
                last = midpoint - 1 #24 - 1
            else:
                first = midpoint + 1
    return found, count

def main():
    lyst = []
    for num in range(1000000):#for however many numbers in 1000000
        lyst.append(num)#Add them to lyst

    found, count = binarySearch(lyst, 675345)#passes in 'lyst' to 'alist', and 675345 into 'item' 
    print("Was number in list?", found)
    print("How many comparisons?", count)#count is how many times the program searched through the list

main()
