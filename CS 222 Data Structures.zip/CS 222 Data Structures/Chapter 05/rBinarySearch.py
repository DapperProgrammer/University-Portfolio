import random
def rBinarySearch(alist, item):
    if len(alist) == 0: #if nothing in list
        return False
    else:
        midpoint = len(alist) // 2 #length of list divided by 2 finds midpoint
        if alist[midpoint] == item:#Check location and see if it is == to the item
            return True
        else:
            if item < alist[midpoint]:#check to see if item is less than location
                return rBinarySearch(alist[:midpoint], item)#check to see if item is less than midpoint value
            else:
                return rBinarySearch(alist[midpoint + 1:], item)#check to see if item is greater than midpoint value

def main():
    lyst = []
    for x in range(1000000):
        lyst.append(x)

    found = rBinarySearch(lyst, 2000000)
    print("Was number in list?", found)

main()

#Hash values
#31/11 = 22
#32-22 = 9 (puts 32 at index 9)
