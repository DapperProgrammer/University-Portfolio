import random

def selectionSort(alist):
    for fillslot in range (len(alist) - 1, 0, -1):
        positionOfMax = 0
        for location in range(1, fillslot + 1):
            if alist[location] > alist[positionOfMax]:
                positionOfMax = location
        temp = alist[fillslot]
        alist[fillslot] = alist[positionOfMax]
        alist[positionOfMax] = temp

def printList(alist):
    count = 0
    for x in range(len(alist)):
        
        if count % 10 == 0:
            print()
        print("%4d" % alist[x], end = " ")
        count += 1

def main():
    lyst = []
    for x in range(100000):
        lyst.append(x)
    random.shuffle(lyst)
    #printList(lyst)
    #print()
    selectionSort(lyst)
    #printList(lyst)

main()
    
