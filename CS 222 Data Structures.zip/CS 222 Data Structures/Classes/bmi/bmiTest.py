from bmi import BMI
def main():
    bmi = BMI("John", 18, 185, 70)
    print("BMI", bmi.getBMI())
    print("Status", bmi.getStatus())
main()
