from gates import *

g1 = OrGate("G1")
g2 = AndGate("G2")
g3 = AndGate("G3")
g4 = NotGate("G4")
g5 = OrGate("G5")
c1 = Connector(g1, g3)
c2 = Connector(g2, g3)
c3 = Connector(g3, g5)
c4 = Connector(g4, g5)
print("g3", g3.getOutput())
print("g4", g4.getOutput())
print("g5", g5.getOutput())
