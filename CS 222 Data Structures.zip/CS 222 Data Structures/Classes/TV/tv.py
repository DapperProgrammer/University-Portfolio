class TV:
    def __init__(self, channel = 1, volume = 1, onOff = False):
        self.channel = channel
        self.volume = volume
        self.onOff = onOff

    def setChannel(self, channel):
        if self.onOff and 1 <= channel <= 120:
            self.channel = channel
        else:
            print("WRONG: must be on and channel 1 to 120")

    def channelUp(self):
        if self.onOff and self.channel < 120:
            self.channel += 1

    def channelDown(self):
        if self.onOff and self.channel > 1:
            self.channel -= 1

    def getChannel(self):
        return self.channel

    def setVolume(self, volume):
        if self.onOff and 0 <= volume <= 7:
            self.volume = volume

    def volumeUp(self):
        if self.onOff and self.volume < 7:
            self.volume += 1

    def volumeDown(self):
        if self.onOff and self.volume > 0:
            self.volume -= 1

    def getVolume(self):
        return self.volume

    def setOnOff(self, onOff):
        self.onOff = onOff

    def getOnOff(self):
        return self.onOff

    def __str__(self):
        msg = "\nTV On? " + str(self.onOff)
        msg += "\nChannel " + str(self.channel)
        msg += "\nVolume " + str(self.volume)
        return msg
