from tv import TV
def main():
    tv1 = TV()
    print(tv1)
    tv1.setOnOff(True)
    tv1.setChannel(56)
    tv1.setVolume(5)
    print(tv1)

    tv2 = TV(60, 4, True)
    print("TV ON?", tv2.getOnOff())
    print("Channel", tv2.getChannel())
    print("Volume", tv2.getVolume())

    tv2.channelUp()
    tv2.channelUp()
    tv2.channelDown()
    tv2.volumeUp()
    tv2.volumeUp()
    tv2.volumeDown()
    print(tv2)
main()
