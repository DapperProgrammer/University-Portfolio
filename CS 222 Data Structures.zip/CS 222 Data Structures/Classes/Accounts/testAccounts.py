from accounts import *

def main():
    print("Enter the following data for a savings account.")
    acctNum = 111
    intRate = .02
    balance = 100.0

    savings = SavingsAccount(acctNum, intRate, balance)
    print()
    print("Savings Account")
    print("---------------")
    print(savings)
    print()
    
    print("Enter the following data for a CD.")
    acctNum = 222
    intRate = .05
    balance = 10000.0
    maturity = "12/31/2021"

    cd = CD(acctNum, intRate, balance, maturity)
    print()
    print("CD")
    print("---------------")
    print(cd)
    savings.deposit(500)
    savings.withdraw(100)
    interest = savings.calcInterest()
    print("Savings Interest: ", interest)
    
    print()
    print("Savings Account")
    print("---------------")
    print(savings)
    interest = cd.calcInterest()
    print("CD Interest: ", interest)
    print()
    print("CD")
    print("---------------")
    print(cd)

main()
