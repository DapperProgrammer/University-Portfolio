import math
class Circle:
    def __init__(self, r = 1):
        self.radius = r

    def getPerimeter(self):
        return 2 * self.radius * math.pi

    def getArea(self):
        return self.radius * self.radius * math.pi

    def setRadius(self, radius):
        self.radius = radius

    def getRadius(self):
        return self.radius

    
