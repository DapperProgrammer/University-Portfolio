class Fraction:
    def __init__(self, top, bottom):
        self.num = top # reference variable to top
        self.den = bottom # reference variable to bottom

    def show(self):
        print(self.num, "/", self.den, sep = "")
        
    def __str__(self):
        msg = str(self.num) + "/" + str(self.den)
        return msg
