from fraction import Fraction

def main():
    frac = Fraction(3, 5) # passes in 3 to top and 5 to bottom
    frac.show() # Calls the show method from the Fraction Class
    print(frac)

main()
