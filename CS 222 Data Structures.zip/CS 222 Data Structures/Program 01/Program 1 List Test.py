line = []

def getData():
    baseball_teams = open('worldSeries.txt','r')
    for item in baseball_teams:
        line = item.split(',')
        year = line[0]
        team_name1 = line[1]
        league1 = line[2]
        win_loss = line[3]
        team_name2 = line[4]
        league2 = line[5]
        lineStrip= map(str.strip, line)
        print(line)

def main():
    getData()


main()
