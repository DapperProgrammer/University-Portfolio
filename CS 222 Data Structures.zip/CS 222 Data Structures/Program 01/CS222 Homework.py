#line12 = []
team_AL_dict = {}
team_NL_dict = {}
year_teams_list = []
option4_dict = {}

def get_Data():
	# Assigns contents of worldSeries.txt to 'baseball_teams' "r" means read
	baseball_teams = open('worldSeries.txt','r')
	# For every line of information in the worldSeries.txt file which is assigned to 'baseball_teams'
	for item in baseball_teams:
		# Split the information by ','
		line = item.split(',')
		# Assign the contents at index '0' to the variable 'year'
		year = line[0]
		team_name1 = line[1]
		league1 = line[2]
		win_loss = line[3]
		team_name2 = line[4]
		league2 = line[5]

		# If league1 in line[2] i1s 'AL'
		if league1 == "AL":
			# check to see if that team is in team_AL_dict
			if team_name1 in team_AL_dict:
				# If the team is already in team_AL_dict, add to score.
				team_AL_dict[team_name1] = team_AL_dict[team_name1] + 1
			else:
				# If team not in team_AL_dict, add team to the dictionary.
				team_AL_dict[team_name1] = 1

		# If league1 in line[2] is 'NL'
		if league1 == "NL":
			if team_name1 in team_NL_dict:
				team_NL_dict[team_name1] +=1
			else:
				team_NL_dict[team_name1] = 1

	for year in line[0]:
		year_teams_list.append(year)
			

"""        
for key, value in team_AL_dict.items(): # For every key and value in dictioanary
	print('Team:', key, 'won', value, 'times,', 'League, AL')
print()
for key, value in team_NL_dict.items():  # .items() tells Python to get every record in the dictionary.
	print('Team:', key, 'won', value, 'times,', 'League, NL')
"""

def AL_winningTeams():
	for key, value in team_AL_dict.items(): # For every key and value in team_AL_dict
		print('Team:', key, 'won', value, 'time(s),', 'League, AL')

	print()
	print("**************************************")	
	print()
	
def NL_winningTeams():
	for key, value in team_NL_dict.items(): # For every key and value in team_NL_dict
		print('Team:', key, 'won', value, 'time(s),', 'League, NL')
		
	print()
	print("**************************************")	
	print()

def specific_team_times_won():
	team_choice = input('Enter a team name: ')
	if team_choice in team_AL_dict:		# check to see if team in AL
		print("The", team_choice, "won", team_AL_dict[team_choice], "time(s)") 	# print out wins associated with team
	elif team_choice in team_NL_dict:	# check to see team in NL
		print("The", team_choice, "won", team_NL_dict[team_choice], "time(s)")	# print out wins associated with team
	else:
		print("Team name not found!")
		
	print()
	print("**************************************")	
	print()
	
 
def specific_team_times_in_World_series():
	user_team_choice = input('Enter a team: ')
	if user_team_choice in team_AL_dict:
		print(user_team_choice, 'were in the World Series', team_AL_dict[user_team_choice], 'times.') #Grabs the users choice associated
	elif user_team_choice in team_NL_dict:
		print(user_team_choice, 'were in the World Series', team_NL_dict[user_team_choice], 'times.')
	else:
		print('Error: No such team exists.')
		
	print()
	print("**************************************")	
	print()


def specific_team_times_in_world_series():
  print(line.count("New York Giants"))
 
  print()
  print("**************************************")	
  print()

"""
def specific_year_who_won_who_lost():
  year_choice = input('Enter a year to see who won and who lost:')
  if year_choice in line:
    print(team_name1, league1, win_loss, team_name2, league2)
  else:
    print('Error: Year not found')
""" 

def main():
	user_choice = 0
	while (user_choice != 6):
		print('1. All willing teams from AL')
		print('2. All winning teams from NL')
		print('3. How many times a specific team has won')
		print('4. Specific team how many times they were in the World Series')
		print('5. Specific year who won who lost')
		print('6. Quit')
		print()
		user_choice = (int(input('Welcome to the main menu, please choose an option: ')))
		print()

		if user_choice == 1:
			AL_winningTeams()
		elif user_choice == 2:
			NL_winningTeams()
		elif user_choice == 3:
			specific_team_times_won()
		elif user_choice == 4:
			specific_team_times_in_world_series()
		elif user_choice == 5:
			specific_year_who_won_who_lost()
		else:
			print('Session ended')

get_Data() #Calls the function 'get_Data'
main() 
  

  
