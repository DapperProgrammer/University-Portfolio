#ID Descroption Quantity

#Get item based on ID
#List all ID quantity, for quantity < 25
#Print total retail inventory


def getItem(ID):
    counter = 0 #intalize to 0
    found = False #Will change to true when item is found
    userID = input('Enter item ID:')
    while counter < len(ID) and not found: #len() means 'length of' variable
        if userID == ID[counter]: #check to see if there is a match
            found = True #if there is a match change to true
        else:
            counter = counter + 1 #if not true add 1

    if found:
        return counter
    else:
        return -1

def findQty(ID, qty):
    for counter in range(0, len(qty)): #0-number of items in the file
        if qty[counter] < 25:
            print(ID[counter], qty[counter])

def totalRetail(qty, price):
    retTotal = 0
    for counter in range(0, len(qty)):
        total = qty[counter] * (1.2 * price[counter])
        retTotal = retTotal + total
    print('Total retail inventory:', retTotal)


def main():
    invFile = open('inventory.txt', 'r')#r means read file
    invID = [] # starts empty list, to have items added later (.append)
    description = []
    quantity = []
    price = []
    for line in invFile: #pulls up 1 line at a time each time through the for loop
        data = line.split(',') #splits info by the ',' comma
        invID.append(data[0])
        description.append(data[1])
        quantity.append(int(data[2]))#changes from string to integer
        price.append(float(data[3]))#changes from string to float
    loc = getItem(invID)
    if loc == -1:
        print('Error item ID not found:')
    else:
        print(invID[loc], description[loc], quantity[loc], price[loc])
    print('Quantities less than 25')
    findQty(invID, quantity)
    totalRetail (quantity, price)

main() #calls main function
