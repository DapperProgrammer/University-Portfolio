#sum() is needed to concatenate all lists to single one

def quick_sort(my_list):
    if len(my_list) < 2: return my_list
    lesser = quick_sort([x for x in my_list[1:] if x <= my_list[0]])
    bigger = quick_sort([x for x in my_list[1:] if x >  my_list[0]])
    return sum([lesser, [my_list[0]], bigger], [])