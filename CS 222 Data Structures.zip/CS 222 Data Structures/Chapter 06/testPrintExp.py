from binaryTree import BinaryTree

def main():
    print("Store ")
    x = BinaryTree("*")
    x.insertLeft("+")
    l = x.getLeftChild()
    l.insertLeft(4)
    l.insertRight(5)
    x.insertRight(7)
    print(x.printexp())
    print(x.postordereval())

main()
