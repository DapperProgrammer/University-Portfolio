from stack import Stack
from binaryTree import BinaryTree
import operator

def buildParseTree(fpexp):
    fplist = fpexp.split()#split the expression(splits by spaces by default)
    pStack = Stack()#create a stack which holds the parent
    eTree = BinaryTree('')#create empty binarytree
    pStack.push(eTree)#push etree on to the stack
    currentTree = eTree
    for i in fplist:
        if i == '(':#if i == a left (            
            currentTree.insertLeft('')#inserts a new node
            pStack.push(currentTree)#pushes currentTree (which is pointing to etree)
            currentTree = currentTree.getLeftChild()#moves currentTree to the newly created node
        elif i not in ['+', '-', '*', '/', ')']:  
            currentTree.setRootVal(int(i))#sets rootVal to equal what value is at the 'i' index
            parent = pStack.pop()#pop currentTree off the pevious node??????
            currentTree = parent
        elif i in ['+', '-', '*', '/']:       
            currentTree.setRootVal(i)
            currentTree.insertRight('')
            pStack.push(currentTree)
            currentTree = currentTree.getRightChild()
        elif i == ')':          
            currentTree = pStack.pop()
        else:
            raise ValueError
    return eTree

def evaluate(parseTree):
    opers = {"+" : operator.add, "-" : operator.sub,
             "*" : operator.mul, "/" : operator.truediv}
    leftC = parseTree.getLeftChild()
    rightC = parseTree.getRightChild()
    if leftC and rightC:
        fn = opers[parseTree.getRootVal()]
        return fn(evaluate(leftC), evaluate(rightC))
    else:
        return parseTree.getRootVal()
    

def main():
    pt = buildParseTree("( ( 10 + 5 ) * 3 )")
    pt.postorder()
    x = evaluate(pt)
    print(x)
main()
