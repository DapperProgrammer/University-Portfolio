from gate import * # '*' imports all the clases including the super class

def main():
    g1 = Or_Gate('G1')
    g2 = And_Gate('G2')
    g3 = And_Gate('G3')
    g4 = Not_Gate('G4')
    g5 = Or_Gate('G5')
    c1 = Connector(g1, g3)
    c2 = Connector(g2, g3)
    c3 = Connector(g3, g5)
    c4 = Connector(g4, g5)
    print('g3', g3.get_output())
    print('g4', g4.get_output())
    print('g5', g5.get_output())
    
main()


#Is-A requires inheritance
#Has-A requires no inheritance
