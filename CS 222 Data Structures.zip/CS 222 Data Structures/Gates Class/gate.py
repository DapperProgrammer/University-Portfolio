#inherit means that class gets all the information form the class it is "inheriting" from

class Logic_Gate:
    def __init__(self, n):
        print('Inside init for Logic_Gate')
        self.label = n #Sets 'self.label' equal to the arguement 'n' 
        self.output = None

    def get_label(self):
        return self.label

    def get_output(self):
        self.output = self.performGate_logic()
        return self.output


class Binary_Gate(Logic_Gate): #Inherits from 'Logic_Gate'
    def __init__(self, n): #n is needed for logic gate value
        super().__init__(n) #needs value n to execute the constructor, we use 'super' to call the '__init__' from the super class, which is Logic_Gate, also has to be first line
        print('Inside init for Binary_Gate')
        self.pinA = None
        self.pinB = None

    def getPinA(self):
        if self.pinA == None: #means we need the pin
            return int(input('EnterPin A input for gate' + \
                         self.get_label() + '-->'))#calls 'get_label' function
        else:
            return self.pinA.get_from().getOutput()

    def getPinB(self):
        return int(input('Enter Pin B input for gate' + \
                         self.get_label() + '-->')) #calls 'get_label' function

    def set_next_pin(self, source):
        if self.PinA == None:
            self.pinA = source
        elif self.pinB == None:
            self.PinB = source
        else:
            print('Cannot connect:', end='')
            print('No empty pins on this gate!')

class Unary_Gate(Logic_Gate): #Inherits from 'Logic_Gate'
    def __init__(self, n):
        super().__init__(n)
        self.pin = None
        print('Inside init for Logic_Gate')
    def getPin(self):
        if self.pin == None:
            return int(input('Enter pin for gate:' + \
                             self.get_label() + '-->'))
        else:
            returnself.pin.get_from().get_output()

    def set_next_pin(self, source):
        if self.pin == None:
            self.pin = source
        else:
            print('Cannot connect: NO EMPTY PINS on this gate')


class And_Gate(Binary_Gate): #inherits from 'Binary_Gate'
    def __init__(self, n):
        super().__init__(n)
        print('Inside init for Binary_Gate')
        
    def performGate_logic(self):
        a = self.getPinA()#calls 'getPinA' function
        b = self.getPinB()#calls 'getPinB' function 
        if a ==1 and b == 1:
            return 1
        else:
            return 0

class Or_Gate(Binary_Gate): #inherits from 'Binary_Gate'
    def __init__(self, n):
        Binary_Gate.__init__(self, n) #Can use this instead of 'super', calls the class to be used

    def performGate_logic(self):
        a = self.getPinA()
        b = self.getPinB()
        if a == 1 and b == 1:
            return 0
        else:
            return 0

class Not_Gate(Unary_Gate):
    def __init__(self, n):
        Unary_Gate.__init__(self, n)

    def performGate_logic(self):
        if self.getPin():
            return 0 #0 represents False
        else:
            return 1

class Connector:
    def __init__(self, fgate, tgate):
        self.from_gate = fgate
        self.to_gate = fgate
        self.to_gate.set_next_pin(self)

    def get_from(self):
        return self.from_gate

    def get_to(self):
        return self.to_gate
