from turtle import *

def drawTriangle(points, color, myTurtle):
    myTurtle.speed(0)#Controls speed
    myTurtle.fillcolor(color)
    myTurtle.up()
    myTurtle.goto(points[0])#goes to points 0
    myTurtle.down()
    myTurtle.begin_fill()
    myTurtle.goto(points[1])#Draw going to points 1
    myTurtle.goto(points[2])#Draw going to points 2
    myTurtle.goto(points[0])#Draw going to points 0
    myTurtle.end_fill()

def getMid(p1, p2):
    return((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)

def sierpinski(points, degree, myTurtle):
    colormap = ["blue", "red", "green", "white", "yellow",
                "violet", "orange", "brown", "pink", "purple", "magenta"
                "black"]
    drawTriangle(points, colormap[degree], myTurtle)#passing in points, colormap[degree], and myTurtle
    if degree > 0:
        sierpinski([points[0],
                    getMid(points[0], points[1]),#add points together divide by 2
                    getMid(points[0], points[2])],
                    degree - 1, myTurtle)
        sierpinski([points[1],
                    getMid(points[0], points[1]),
                    getMid(points[1], points[2])],
                    degree - 1, myTurtle)
        sierpinski([points[2],
                    getMid(points[2], points[1]),
                    getMid(points[0], points[2])],
                    degree - 1, myTurtle)

def main():
    myTurtle = Turtle()
    myWin = myTurtle.getscreen()
    myPoints = [(-500, -250), (0, 500), (500, -250)]#Starting points
    sierpinski(myPoints, 7, myTurtle)#Number depends on the amount of colors you have
    myWin.exitonclick()
main()
