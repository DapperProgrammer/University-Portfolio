def listSum(numList):
    if len(numList) == 1:
        print(numList[0])
        return numList[0]
    else:
        print(numList[0], "+", numList[1:])
        return numList[0] + listSum(numList[1:])

def main():
    lyst = [1, 3, 5, 7, 9]
    print(listSum(lyst))

main()
