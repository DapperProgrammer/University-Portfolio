def toStr(n, base):
    convertString = "0123456789ABCDEF"
    if n < base:
        print(convertString[n])
        return convertString[n]
    else:
        print(n // base, "+", convertString[n % base])
        return toStr(n // base, base) + convertString[n % base]

def main():
    value = 47
    base = 2
    print(toStr(value, base))

main()
