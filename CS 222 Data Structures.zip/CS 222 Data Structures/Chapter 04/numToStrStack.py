from stack import Stack
#base = 10 value = 769
# [n % base] is dividing n by base which will have a remainder
# value == n

rStack = Stack()
def toStrStack(n, base):
    convertString = "0123456789ABCDEF"
    if n < base:
        rStack.push(convertString[n])
    else:
        rStack.push(convertString[n % base])
        toStrStack(n // base, base)

def main():
    value = 769
    base = 10
    toStrStack(value, base)
    outputString = ""
    while not rStack.isEmpty():
        outputString += rStack.pop()
    print(outputString)
    

main()
