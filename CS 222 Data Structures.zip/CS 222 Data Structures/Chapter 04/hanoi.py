def movTower(height, fromPole, toPole, withPole):
    if height >= 1:
        movTower(height - 1, fromPole, withPole, toPole)
        moveDisk(fromPole, toPole)
        movTower(height - 1, withPole, toPole, fromPole)

def moveDisk(fp, tp):
    print("Moving disk from %d to %d" % (fp, tp))

def main():
    movTower(4, 1, 2, 3)# number of discs = 15, number of pegs = 123
main()

#number of discs is 2 to the 4th power - 1
# 5 discs is 2^5-1
