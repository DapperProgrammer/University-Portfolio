from turtle import *

#import all methods from turtle class

def drawSpiral(myTurtle, lineLen):
    if lineLen > 0:
        myTurtle.forward(lineLen)#moves forward after the drawSpiral calculation
        myTurtle.right(90)#Controls the shape (90degrees is a swuare)
        drawSpiral(myTurtle, lineLen - 3)#300-3, controls the gap inbetween lines

def main():
    myTurtle = Turtle() #create object of myTurtle
    myWin = myTurtle.getscreen()
    myTurtle.penup()
    myTurtle.right(90)
    myTurtle.forward(100)
    myTurtle.right(180)
    myTurtle.pendown()
    drawSpiral(myTurtle, 300)#Calls drawSpirtal giving it 300 units to 'lineLen'
    myWin.exitonclick() #exits program

main()
