from turtle import *

def tree(branchLen, t):
    if branchLen > 2:#if 110 is > 2
        if branchLen < 10: #if 110 is < 10
            t.color("green")
        else:
            t.color("brown")
        t.forward(branchLen)
        t.right(20)
        tree(branchLen - 15, t)#110 - 15
        t.left(40)
        tree(branchLen - 10, t)
        t.right(20)
        t.backward(branchLen)

def main():
    t = Turtle()
    t.speed(0)#Controls speed 
    myWin = t.getscreen()
    t.left(90)
    t.up()
    t.backward(300)
    t.down()
    t.color("brown")
    tree(110, t) #passes in 110 to 'branchLen'
    myWin.exitonclick()
main()
