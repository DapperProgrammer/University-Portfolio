import random
from qu import Queue

class Printer:
    def __init__(self, ppm):
        self.pagerate = ppm
        self.currentTask = None #There is nothing in current task (meaning there is no current printer task)
        self.timeRemaining = 0 #the time renaiming is 0

    def tick(self):#Check to see if there is a print task
        if self.currentTask != None: #if there IS a print task
            self.timeRemaining -= 1 #Subtract 1 from time remaining 
            if self.timeRemaining <= 0: #if self.timeRemaining has a value of <= 0
                self.currentTask = None #Then set self.currentTask = None 

    def busy(self):#check to see if printer is busy
        if self.currentTask != None: #if there IS a print task
            return True #printer is busy
        else:
            return False #Printer is not busy

    def startNext(self, newTask): #Start a new print task
        self.currentTask = newTask#changes self.currentTask from 'none' to the value of newTask
        self.timeRemaining = newTask.getPages() * 60 / self.pagerate #'self.pages' * 60 / 'self.pagerate', which gets its value from: labPrinter = Printer(pagesPerMinute), which gets its value from: simulation.

class Task:
    def __init__(self, time):
        self.timestamp = time
        self.pages = random.randrange(1, 21)#random pages between 1 and 20

    def getStamp(self):
        return self.timestamp

    def getPages(self):
        return self.pages

    def waitTime(self, currenttime):0
        return currenttime - self.timestamp

def simulation(numSeconds, pagesPerMinute):#21600 seconds, 5 pages per minute
    labPrinter = Printer(pagesPerMinute)#Creates labPrinter as an object of the Printer Class, passing in pagesPerMinute into ppm
    printQueue = Queue()#Creates printQueue as an Object of the Queue Class
    waitingTimes = []#Initialize empty list called 'waitingTimes'
    for currentSecond in range(numSeconds):#for however many seconds in 'numSeconds'
        if newPrintTask(): #calls the newPrintTask method
            task = Task(currentSecond)#Calls the Task Class passing in 'currentSecond' to 'time'
            printQueue.enqueue(task)#Add 'task' to the que list
        if (not labPrinter.busy()) and (not printQueue.isEmpty()):  #If lab printer is not busy and the print queue is not empty
            nexttask = printQueue.dequeue()  #Create new print task from the print queue
            waitingTimes.append(nexttask.waitTime(currentSecond))#Add the 'waitTime' to the 'waitingTimes' list 
            labPrinter.startNext(nexttask)#Start a new print task passing in the value of 'nexttask'
        labPrinter.tick()#Calls the 'tick' method 
    averageWait = sum(waitingTimes) / len(waitingTimes)
    print("Average Wait %6.2f secs %3d tasks remaining"
          % (averageWait, printQueue.size()))

def newPrintTask():
    num = random.randrange(1, 181)#random number between 1 and 180
    if num == 180:
        return True
    else:
        return False

def main():
    simulation(21600, 5)#Passes in '21600' into numSeconds and '5' into PagesPerMinute

main()
