from node import Node

class UnorderedList:
    def __init__(self):
        self.head = None

    def isEmpty(self):
        return self.head == None

    def add(self, item):
        temp = Node(item)
        temp.setNext(self.head)# Head Variable
        self.head = temp

    def length(self):
        current = self.head #Holds the address of what head is pointing to
        count = 0 #counter variable
        while current != None: #None is end of list
            count += 1
            current = current.getNext()#Holds address to next link
        return count

    def search(self, item):
        current = self.head
        found = False
        while current!= None and not found: #Havent hit the end of list and still havent found item
            if current.getData() == item: #calls getData from Node Class
                found = True #found the item this makes the variable "found" equal True
            else:
                current = current.getNext()#else keep moving on till item is found
            return found

    def remove(self, item):
        current = self.head
        previous = None #initialize previous as None
        found = False
        while not found:
            if current.getData() == item:
                found = True #stops loop
            else:
                previous = current #move previous to current, if removing from first node
                current = current.getNext() #move current to current.getNext
        if previous == None:
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())
        



    

    def printList(self):
        current = self.head
        while current != None:
            print(current.getData(), end = " ")#prints data on same line
            current= current.getNext()
        print()
        
        
