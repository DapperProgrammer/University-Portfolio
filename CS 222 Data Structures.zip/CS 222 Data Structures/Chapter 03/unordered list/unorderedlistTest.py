from unorderedlist import UnorderedList

def main(): #tests printList, isEmpty, add, and search, 
    myList = UnorderedList() #Create object of unordered list class
    print("Is my list empty?", myList.isEmpty())#Testing isEmpty method
    print("Add 3 items")
    myList.add(93)
    myList.add(71)
    myList.add(38)
    print("Length", myList.length())
    print("List Values")
    print(myList.printList())
    print("Add 2 more items")
    myList.add(64)
    myList.add(45)
    print("Is my list empty?", myList.isEmpty())
    print("List Values")
    myList.printList()

    print("Is 38 in the list?", myList.search(38))#testing the search method
    print("Is 99 in the list?", myList.search(99))

    print("removing 38")
    myList.remove(38)
    myList.printList()
    

main()
