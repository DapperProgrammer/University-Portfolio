from node import Node


class OrderedList:
    def __init__(self):
        self.head = None

    def isEmpty(self): #is the list empty
        return self.head == None

    def add(self, item):#add item
        temp = Node(item)
        temp.setNext(self.head)# Head Variable
        self.head = temp

    def length(self):#count how many items in list
        current = self.head #Holds the address of what head is pointing to
        count = 0 #counter variable
        while current != None: #None is end of list
            count += 1
            current = current.getNext()#Holds address to next link
        return count

    def search(self, item):
        current = self.head
        found = False
        stop = False
        while current!= None and not found: #Havent hit the end of list and still havent found item
            if current.getData() == item: #calls getData from Node Class
                found = True #found the item this makes the variable "found" equal True
            else:
                current = current.getNext()#else keep moving on till item is found
            return found

    def remove(self, item):
        current = self.head
        previous = None #initialize previous as None
        found = False
        while not found:
            if current.getData() == item:
                found = True #stops loop
            else:
                previous = current #move previous to current, if removing from first node
                current = current.getNext() #move current to current.getNext
        if previous == None:
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())


    def add(self, item):
        current = self.head
        previous = False
        stop = False
        while previous != None and not stop:
            if current.getData() > item: #check if current.getData is greater thatn item we want to put in
                stop = True#if the item IS greater
            else:#if it is not
                previous = current
                current = current.getNext()

    temp = None(item)
    if previous ==None:
        temp.setNext(self.head)
        self.head = temp
    else:
        temp.setNext(current)
        previous.setNext(temp)
                
                
        



    

    def printList(self):
        current = self.head
        while current != None:
            print(current.getData(), end = " ")#prints data on same line
            current= current.getNext()
        print()
        
        
