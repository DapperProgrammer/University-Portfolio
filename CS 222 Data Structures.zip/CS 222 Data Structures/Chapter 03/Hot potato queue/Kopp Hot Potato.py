from qu import Queue
import random
def hotPotato(namelist):
    simQueue = Queue()#Creates simQueue as an object of the Queue Class
    for name in namelist:#For however many names in namelist
        simQueue.enqueue(name)#Add them to the queue
    while simQueue.size() > 1:#While the queue list is greater than 1
        numbers = random.randint(2, 20)
        for num in range(numbers):#For however many numbers in num
            simQueue.enqueue(simQueue.dequeue())#???
        simQueue.dequeue()
    return simQueue.dequeue()

def main():
    names = ["Bill", "Mary", "Sally", "Peggy", "Larry", "Frank"]
    winner = hotPotato(names)
    print(winner)

main()
