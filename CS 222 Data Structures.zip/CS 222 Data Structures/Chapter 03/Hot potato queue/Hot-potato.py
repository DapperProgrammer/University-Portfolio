class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item): #Add item
        self.items.insert(0, item)

    def dequeue(self): #Remove item
        return self.items.pop()

    def size(self):
        return len(self.items)

def hot_potato(name_list, num):
    name_list = ['Bob', 'David', 'Jane']
    num = 7
    q = Queue()
    for name in name_list:
      q.enqueue(name)
      
    while q.size() > 1:
      for integer in range(num):
        q.enqueue(q.dequeue())
        
      q.dequeue()
      
    print(q.dequeue())
  

#page 111