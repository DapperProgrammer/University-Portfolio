#Once a variable is defined in the 'def __init__' method, in this case the variable is 'self.items'. It can be used anywhere in the class it is defined in. The variable may also be used in other classes if its class is a super class for the sub class you are trying to use it in.

class Stack:
    def __init__(self):
        self.items = [] #creates an empty STACK list

    def isEmpty(self):
        return self.items == [] #return an empty STACK list

    def push(self, item):
        self.items.append(item) #add an item to the STACK list

    def pop(self):
        return self.items.pop() #remove last entered item from the STACK list

    def peek(self):
        return self.items[len(self.items) - 1] #???

    def size(self):
        return len(self.items) #Prints the length STACK list
    

def main():
  school_grades = 0
  while school_grades != 'DONE':
    grade_list = []
    s = Stack() #Creates 's' as an object of the class 'Stack', allows the use of the class in 'main'
    school_grades = input('Please enter grade: ')
    if school_grades == 'DONE':
      print('Session ended: ')
    else:
      grade_list.append(school_grades)
      print(grade_list)
  print(grade_list)
   
    #elif school_grades == 'REVERSE':
     # s.pop
    #else:
      #s.push(school_grades)
    





main()