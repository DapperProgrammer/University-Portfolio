from fractionclass import Fraction

def main():
    frac1 = Fraction(3,5)
    frac2 = Fraction(1,4)
    frac3 = Fraction(3,4)
    frac4 = Fraction(6,8)
    frac1.show() #calls the function show, which changes 3,5 in 'frac' to 3/5
    print(frac1)
    print(frac1 + frac2)
    print(frac1 == frac2)
    print(frac3 == frac4)
main()
