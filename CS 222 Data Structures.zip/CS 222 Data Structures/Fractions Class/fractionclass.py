class Fraction:
    def __init__(self, top, bottom):
        self.numerator = top
        self.denominator = bottom

    def show(self):
        print(self.numerator,'/',self.denominator,sep='') #sep means seperate by something

    def __str__(self): #Allows the method print to print out an actual fraction
        msg = str(self.numerator) + '/' + str(self.denominator)
        return msg

    def __add__(self, other):
        new_numerator = self.numerator * other.denominator + \
                        self.denominator * other.numerator
        new_denominator = self.denominator * other.denominator
        common = self.gcd(new_numerator, new_denominator)
        return Fraction(new_numerator // common, new_denominator // common)

    def gcd(self, m, n): #Eculid's algorithim 
        while m % n != 0:
            oldm = m
            oldn = n
            m = oldn
            n = oldm % oldn
        return n
    
    def __eq__(self, other):
        first_numerator = self.numerator * other.denominator
        second_numerator = self.denominator * other.numerator
        return first_numerator == second_numerator
