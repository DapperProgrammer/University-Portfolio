def main():
    salesFile = open("sales.txt", "r")
    line = salesFile.readline()
    while line != "":
        amount = float(line)
        print(format(amount, ".2f"))
        line = salesFile.readline()
    salesFile.close()

main()
