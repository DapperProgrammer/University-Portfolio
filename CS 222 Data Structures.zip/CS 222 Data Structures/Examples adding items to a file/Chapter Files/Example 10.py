def main():
    salesFile = open("sales.txt", "r")
    for line in salesFile:
        amount = float(line)
        print(format(amount, ".2f"))
    salesFile.close()

main()
