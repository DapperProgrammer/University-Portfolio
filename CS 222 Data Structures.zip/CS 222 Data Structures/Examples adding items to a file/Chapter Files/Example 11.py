def main():
    total = 0
    filename = input("Enter the employee filename: ")
    empFile = open(filename, "r")
    payrollFile = open("payroll.txt", "w")
    payrollFile.write("Name           Pay Rate   Hours   Wages\n")
    for line in empFile:
        data = line.split(",")
        name = data[0]
        payrate = float(data[1])
        numHours = int(data[2])
        wages = payrate * numHours
        payrollFile.write("%-15s%8.2f%8d%8.2f\n" %(name, payrate, numHours, wages))
        total += wages
    payrollFile.write("\nTotal Wages: %8.2f" % total)
        

main()
