def main():
    numDays = int(input("For how many days do you have sales? "))
    salesFile = open("sales.txt", "w")
    for count in range(1, numDays + 1):
        sales = float(input("Enter the sales for day #" + str(count) + ": "))
        salesFile.write(str(sales) + "\n")
    salesFile.close()
    print("Data written to sales.txt")

main()
