import random

class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item): #Add item
        self.items.insert(0, item)#Insert adds items to the BACK of the queue list

    def dequeue(self): #Remove item
        return self.items.pop()

    def size(self):
        return len(self.items)
        
class Employee:
    def __init__(self, employee_process_time): 
        self.customer_rate = employee_process_time
        self.current_task = None #initialize the variable to hold a value of None: None means there is nothing in the variable.
        self.time_remaining = 0 #initialize the variable to hold a value of 0

    def customer_line(self):#Check to see if the employee has a customer
        if self.current_task != None: #If self.current_task has a value
            self.time_remaining = self.time_remaining - 1 #subtract 1 from it 
            if self.time_remaining <= 0: #if self.time_remaining is <= 0
                self.current_task = None #Set self.current_task back to None 

    def employee_busy(self):#check to see if the employee is busy
        if self.current_task != None:#if the employee has a customer
            return True#return True
        else:
            return False#if he does not have a customer return false
			
    #def set_employee_to_busy(self):
        #self.current_task = 1
		
    def start_next_customer(self, new_customer):
        self.current_task = new_customer#changes self.currentTask from 'None' to the value of 'new_customer'
        self.time_remaining = new_customer.get_num_customers() * 60 / self.customer_rate#This is the time the employee can process a customer
    
class Task:
    def __init__(self, time):
      self.timestamp = time  # This is the time the customer enters the checkout queue
      self.customers = random.randrange(1, 21)#random customers between 1 and 20
    
    def get_timestamp(self):
      return self.timestamp
    
    def get_num_customers(self):#Obtains a number of customers anywhere between 1 and 20
      return self.customers
      
    def wait_time(self, current_time):
        return current_time - self.timestamp
      
def simulation(num_customers, employee_process_time):#2000 customers, time to process a customer
    store_employee = Employee(employee_process_time)#Creates store_employee as an object of the Employee Class, passing in employee_process_time into customer_per_min
    q = Queue()#Object of Queue Class
    wait_times = [] #Initialize empty list called 'wait_times'
    for current_customer in range(num_customers):#for however many customers in 'num_customers'
        if next_customer(): #calls the 'next_customer' method and if the method returns 'True' (if it had a value of 180), then the 'if' statement is set to 'True' because for  
															#an 'if' statement to return 'True, it must have the stated value (180) that is true to be executed ( any positive value)
            task = Task(current_customer)#Creates task as an object of Task passing in current_customer
            q.enqueue(task)#Add 'task' to the queue list
        if (not store_employee.employee_busy()) and (not q.isEmpty()):#If store_employee is NOT busy and the print queue is NOT empty
            next_task = q.dequeue()#Create new print task from the customer queue
            wait_times.append(next_task.wait_time(current_customer))#Add 'next_task' calling the 'wait_time' method passing in the value of 'current_customer' to 'current_time' then adds the result to the 'wait_times' list
            store_employee.start_next_customer(next_task)#Calls the 'start_next_customer' method passing in the value of 'next_task' into 'new_customer'
        store_employee.customer_line()#Calls the 'customer_line' method which checks to see if the store employee is busy (is with a customer)
    average_wait = sum(wait_times) / len(wait_times)#Divides the total sum of 'wait_times' divided by its length
    print("Average Wait %6.2f secs %3d tasks remaining"
          % (average_wait, q.size()))
    

def next_customer():
    num = random.randrange(1, 181)#random number between 1 and 180
    if num == 180: #If 'num' returns a value of '180': this means the customer has groceries to check out
        return True
    else:
        return False
		
		# You could use the following:
		# while (num == 180):
		#     return True
		# return False
		

def main():
    simulation(2000, random.randrange(5, 16))#Passes in '2000' into num_customers and '5-15' into employee_process_time
											 #This method will be called 2000 times and will generate that many random employee procces time numbers 

main()
    
    
    
    
    
    

	