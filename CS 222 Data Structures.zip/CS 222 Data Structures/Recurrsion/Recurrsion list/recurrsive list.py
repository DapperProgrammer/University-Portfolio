#pg 151

def list_sum(num_list):
    if len(num_list) == 1: #if the length of num list = 1
        print('End', num_list[0])
        return num_list [0]
    else:
        print('First + rest of list:', num_list[0], (num_list[1:]))
        return num_list [0] + list_sum(num_list[1:])



def main():
    my_list = [1, 3, 5, 7, 9]
    print(list_sum(my_list))
    print('List is added in reverse in recurrsion, 7 + 9 is 16, this replaces the 7 and 9 and the next step is 5 + 16 which replaces 5, 7, and 9, then 3 + 21 ect.')

main()
    
