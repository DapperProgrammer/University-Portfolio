def to_string(n, base): #n = 769 base = 10
    convertString = "0123456789ABCDEF"
    if n < base: #if 769 < 10
        print('End', convertString[n])
        return convertString[n]
    else: #its not
        print('to string + convert', n // base, convertString[n % base])
        
        return to_string( n // base, base) + convertString[n % base] #769 // 10

def main():
    number = 769
    base = 10
    print(to_string(number, base))
main()
